# Призма — протокол связи с SWS, Smart Bubbles и агентом дозвона

Имена приложений в шине: `prisma`, `sb`, `sws`, `caller`.
Сервер: den_bus.py, заголовок `X-Bus-Token`. Каждое приложение раз в N секунд читает
`GET /inbox?app=<своё имя>&since=<последний id>` и запоминает максимальный id.

## Призма отправляет
| to | type | payload |
|---|---|---|
| sb | mail.draft | subject, body, url?, ref? |
| sb | brief.item | title, text, url?, status?, transcript? — пункт для голосового брифинга |
| sws | restaurant.add | name, address, phone, cuisine, price, hours, rating, note, url |
| sws | food.note | title, kind, kcal_per_portion, protein_g, fat_g, carbs_g, ingredients[], note, url |
| sws | workout.note | title, muscle_groups[], exercises[{name,sets,reps}], note, url |
| caller | call.task | phone, name, goal, details, language (auto/es/en/ru), script (markdown), source_url, report_to[], requested_by |
| любой | analyze.result | ref (id запроса), q, report (markdown), confidence, actions[], tags[] |
| любой | analyze.error | ref, error |

## Призма принимает (to: prisma)
| type | payload | что делает |
|---|---|---|
| analyze | q, url?, text?, depth (fast/deep/max)?, roles[]?, web? | запускает агентов в фоне, ответ отправителю — analyze.result |
| call.status | task_id (= id сообщения call.task), status | обновляет статус задачи |
| call.result | task_id, status, summary, transcript?, name?, phone? | показывает итог; если включено — пересылает в sb как brief.item |
| open | url | открывает вкладку |

## Без сервера
- Ссылки: `prisma://open?url=`, `prisma://analyze?url=&q=&depth=`, `prisma://ask?q=`, `prisma://links`
- «Поделиться» текстом в Призму — открывает анализ.
- Если сервер не настроен, Призма отправляет через «Поделиться» в пакет приложения (EXTRA_TEXT);
  в конце текста строка `#prisma {"type":...,"payload":{...}}` — её можно разобрать.

## Роли агентов
analyst, skeptic, researcher (веб-поиск), practitioner, contrarian, forecaster, historian.
