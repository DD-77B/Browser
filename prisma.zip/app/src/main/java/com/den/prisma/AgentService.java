package com.den.prisma;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Keeps the app process alive while agents work, so Den can switch to other apps. */
public class AgentService extends Service {
    static final String CH_WORK = "agents_work", CH_DONE = "agents_done";

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CH_WORK, "Агенты работают", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_DONE, "Готовые ответы агентов", NotificationManager.IMPORTANCE_DEFAULT));
    }

    static PendingIntent open(Context c, String route, int code) {
        Intent i = new Intent(c, MainActivity.class).putExtra("openRoute", route)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        channels(this);
        String text = intent != null && intent.getStringExtra("text") != null ? intent.getStringExtra("text") : "Агенты работают";
        Notification n = new Notification.Builder(this, CH_WORK)
                .setSmallIcon(R.drawable.ic_prism)
                .setContentTitle("Призма")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(open(this, "agents", 1))
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(1, n);
        } catch (Exception e) { stopSelf(); }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
