package com.den.prisma;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Saved logins. The whole list is encrypted with an AES-256-GCM key that lives in the Android Keystore
 * (the key never leaves the secure hardware). Passwords are never handed to the panel JS or to any AI model.
 */
public class Vault {
    private static final String ALIAS = "prisma_vault_v1";
    private final SharedPreferences sp;

    public Vault(Context c) { sp = c.getSharedPreferences("prisma_vault", Context.MODE_PRIVATE); }

    public static String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return "";
            h = h.toLowerCase();
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return ""; }
    }

    /** same site if hosts are equal or one is a subdomain of the other's registrable part (accounts.google.com ~ google.com) */
    public static boolean sameSite(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;
        return a.endsWith("." + b) || b.endsWith("." + a) || base(a).equals(base(b));
    }

    private static String base(String h) {
        String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        String last2 = p[p.length - 2] + "." + p[p.length - 1];
        // co.uk, com.es style second-level domains
        if (p[p.length - 2].length() <= 3 && p.length >= 3) return p[p.length - 3] + "." + last2;
        return last2;
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return kg.generateKey();
    }

    private synchronized JSONArray load() {
        String blob = sp.getString("blob", null);
        if (blob == null) return new JSONArray();
        try {
            byte[] all = Base64.decode(blob, Base64.NO_WRAP);
            byte[] iv = new byte[12];
            System.arraycopy(all, 0, iv, 0, 12);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            byte[] pt = c.doFinal(all, 12, all.length - 12);
            return new JSONArray(new String(pt, StandardCharsets.UTF_8));
        } catch (Exception e) { return new JSONArray(); }
    }

    private synchronized void store(JSONArray a) {
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV();
            byte[] ct = c.doFinal(a.toString().getBytes(StandardCharsets.UTF_8));
            byte[] all = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, all, 0, iv.length);
            System.arraycopy(ct, 0, all, iv.length, ct.length);
            sp.edit().putString("blob", Base64.encodeToString(all, Base64.NO_WRAP)).apply();
        } catch (Exception ignored) {}
    }

    /** List without passwords — safe to give to the UI. */
    public String listPublic() {
        JSONArray a = load(), out = new JSONArray();
        try {
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i), p = new JSONObject();
                p.put("id", o.optString("id")); p.put("host", o.optString("host")); p.put("user", o.optString("user"));
                p.put("url", o.optString("url")); p.put("t", o.optLong("t"));
                out.put(p);
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    public JSONObject get(String id) {
        JSONArray a = load();
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && id.equals(o.optString("id"))) return o; }
        return null;
    }

    public java.util.List<JSONObject> forHost(String host) {
        java.util.List<JSONObject> r = new java.util.ArrayList<>();
        JSONArray a = load();
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && sameSite(host, o.optString("host"))) r.add(o); }
        return r;
    }

    /** 0 = same as saved, 1 = new, 2 = password changed */
    public int status(String host, String user, String pass) {
        for (JSONObject o : forHost(host)) {
            if (o.optString("user").equals(user)) return o.optString("pass").equals(pass) ? 0 : 2;
        }
        return 1;
    }

    public void save(String host, String user, String pass, String url) {
        JSONArray a = load();
        try {
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (sameSite(host, o.optString("host")) && o.optString("user").equals(user)) {
                    o.put("pass", pass); o.put("t", System.currentTimeMillis());
                    if (url != null && !url.isEmpty()) o.put("url", url);
                    store(a); return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("id", "v" + System.currentTimeMillis()); o.put("host", host); o.put("user", user); o.put("pass", pass);
            o.put("url", url == null ? "" : url); o.put("t", System.currentTimeMillis());
            a.put(o); store(a);
        } catch (Exception ignored) {}
    }

    public void update(String id, String host, String user, String pass) {
        JSONArray a = load();
        try {
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (id.equals(o.optString("id"))) {
                    if (host != null && !host.isEmpty()) o.put("host", host);
                    if (user != null) o.put("user", user);
                    if (pass != null && !pass.isEmpty()) o.put("pass", pass);
                    o.put("t", System.currentTimeMillis());
                }
            }
            store(a);
        } catch (Exception ignored) {}
    }

    public void delete(String id) {
        JSONArray a = load(), b = new JSONArray();
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && !id.equals(o.optString("id"))) b.put(o); }
        store(b);
    }

    /** personal data for forms (encrypted the same way as passwords) */
    public synchronized String getProfile() {
        String blob = sp.getString("profile", null);
        if (blob == null) return "{}";
        try {
            byte[] all = Base64.decode(blob, Base64.NO_WRAP);
            byte[] iv = new byte[12]; System.arraycopy(all, 0, iv, 0, 12);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(c.doFinal(all, 12, all.length - 12), StandardCharsets.UTF_8);
        } catch (Exception e) { return "{}"; }
    }

    public synchronized void setProfile(String json) {
        try {
            JSONObject o = new JSONObject(json);
            o.remove("ccCsc"); // the card security code is never stored
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV(), ct = c.doFinal(o.toString().getBytes(StandardCharsets.UTF_8));
            byte[] all = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, all, 0, iv.length); System.arraycopy(ct, 0, all, iv.length, ct.length);
            sp.edit().putString("profile", Base64.encodeToString(all, Base64.NO_WRAP)).apply();
        } catch (Exception ignored) {}
    }

    /** what is filled in, without values: for the UI and for matching form fields */
    public String profileSummary() {
        try {
            JSONObject o = new JSONObject(getProfile()), out = new JSONObject();
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) { String k = it.next(); if (!o.optString(k).isEmpty()) out.put(k, true); }
            String n = o.optString("ccNumber").replaceAll("\\D", "");
            if (n.length() >= 4) out.put("ccLast4", n.substring(n.length() - 4));
            return out.toString();
        } catch (Exception e) { return "{}"; }
    }

    public boolean never(String host) { return sp.getStringSet("never", new java.util.HashSet<>()).contains(host); }
    public void addNever(String host) {
        java.util.Set<String> s = new java.util.HashSet<>(sp.getStringSet("never", new java.util.HashSet<>()));
        s.add(host); sp.edit().putStringSet("never", s).apply();
    }
}
