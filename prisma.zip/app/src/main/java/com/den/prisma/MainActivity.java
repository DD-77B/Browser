package com.den.prisma;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.res.ColorStateList;
import android.view.SoundEffectConstants;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;

public class MainActivity extends Activity {

    static class Tab {
        WebView wv; boolean incognito; boolean desktop;
        String url = ""; String title = ""; String pendingAgents = null;
    }

    final List<Tab> tabs = new ArrayList<>();
    int cur = -1;
    FrameLayout stack, content, fullscreenHolder;
    WebView panel;
    boolean panelReady = false, panelOpen = false;
    final List<String> panelQueue = new ArrayList<>();
    EditText address;
    TextView tabsBtn, incogDot;
    ProgressBar progress;
    AdBlock adblock;
    SharedPreferences prefs;
    String extractJs = "";
    ValueCallback<Uri[]> fileCb;
    View customView; WebChromeClient.CustomViewCallback customCb;
    final Handler ui = new Handler(Looper.getMainLooper());
    boolean dark;
    int cBar, cText, cField, cAccent, cMute;
    LinearLayout rootView, barView;
    final List<ImageView> icons = new ArrayList<>();
    View tabsBox; ImageView aiIcon;

    static final String DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";

    int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("prisma", MODE_PRIVATE);
        String th = prefs.getString("theme", "auto");
        dark = th.equals("dark") || (!th.equals("light") && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        pickColors();

        try (InputStream in = getAssets().open("extract.js")) { extractJs = readAll(in); } catch (Exception ignored) {}
        adblock = new AdBlock(this);
        adblock.enabled = prefs.getBoolean("adblock", true);
        adblock.loadAsync();

        LinearLayout root = new LinearLayout(this);
        rootView = root;
        root.setOrientation(LinearLayout.VERTICAL);

        stack = new FrameLayout(this);
        content = new FrameLayout(this);
        content.setBackgroundColor(Color.WHITE);
        stack.addView(content, new FrameLayout.LayoutParams(-1, -1));
        panel = new WebView(this);
        panel.setVisibility(View.GONE);
        stack.addView(panel, new FrameLayout.LayoutParams(-1, -1));
        fullscreenHolder = new FrameLayout(this);
        fullscreenHolder.setBackgroundColor(Color.BLACK);
        fullscreenHolder.setVisibility(View.GONE);
        stack.addView(fullscreenHolder, new FrameLayout.LayoutParams(-1, -1));
        root.addView(stack, new LinearLayout.LayoutParams(-1, 0, 1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));
        root.addView(buildToolbar(), new LinearLayout.LayoutParams(-1, dp(56)));
        setContentView(root);
        applyColors();

        setupPanel();
        if (!handleIntent(getIntent())) {
            String last = prefs.getString("lastUrl", "");
            newTab(last.isEmpty() ? prefs.getString("home", "https://yandex.ru") : last, false);
        }
    }

    // ---------- toolbar (same look as SWS / Smart Bubbles: iOS-style bar, violet accent, line icons) ----------
    void pickColors() {
        // Smart Bubbles palette
        cAccent = dark ? Color.parseColor("#8B72FF") : Color.parseColor("#6A4AF0");
        cBar = dark ? Color.BLACK : Color.parseColor("#F2F2F7");
        cText = dark ? Color.WHITE : Color.BLACK;
        cField = dark ? Color.parseColor("#1C1C1E") : Color.parseColor("#E4E4E9");
        cMute = Color.parseColor("#8E8E93");
    }

    void applyColors() {
        getWindow().setStatusBarColor(cBar);
        getWindow().setNavigationBarColor(cBar);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
        rootView.setBackgroundColor(cBar);
        barView.setBackgroundColor(cBar);
        for (ImageView iv : icons) iv.setImageTintList(ColorStateList.valueOf(cAccent));
        address.setTextColor(cText);
        address.setHintTextColor(cMute);
        GradientDrawable g = new GradientDrawable();
        g.setColor(cField); g.setCornerRadius(dp(12));
        address.setBackground(g);
        GradientDrawable tg = new GradientDrawable();
        tg.setStroke(dp(2), cAccent); tg.setCornerRadius(dp(6));
        tabsBox.setBackground(tg);
        tabsBtn.setTextColor(cAccent);
        incogDot.setTextColor(cAccent);
        progress.setProgressTintList(ColorStateList.valueOf(cAccent));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(cBar));
        panel.setBackgroundColor(cBar);
    }

    View click(View v, View.OnClickListener l) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true);
        v.setBackgroundResource(tv.resourceId);
        v.setOnClickListener(x -> { haptic(); l.onClick(x); });
        return v;
    }

    ImageView icon(int res, View.OnClickListener l) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        icons.add(iv);
        click(iv, l);
        return iv;
    }

    View buildToolbar() {
        LinearLayout bar = new LinearLayout(this);
        barView = bar;
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), 0, dp(4), 0);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(40), dp(48));

        bar.addView(icon(R.drawable.ic_back, v -> { Tab t = tab(); if (t != null && t.wv.canGoBack()) t.wv.goBack(); }), bp);
        bar.addView(icon(R.drawable.ic_fwd, v -> { Tab t = tab(); if (t != null && t.wv.canGoForward()) t.wv.goForward(); }), bp);

        FrameLayout addrWrap = new FrameLayout(this);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextSize(16);
        address.setHint("Адрес, поиск или ? вопрос агентам");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setSelectAllOnFocus(true);
        address.setPadding(dp(12), 0, dp(26), 0);
        address.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_GO || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(address.getText().toString()); return true;
            }
            return false;
        });
        addrWrap.addView(address, new FrameLayout.LayoutParams(-1, dp(38), Gravity.CENTER_VERTICAL));
        incogDot = new TextView(this);
        incogDot.setText("◐"); incogDot.setTextSize(14); incogDot.setVisibility(View.GONE);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        ip.rightMargin = dp(8);
        addrWrap.addView(incogDot, ip);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(38), 1);
        ap.leftMargin = dp(4); ap.rightMargin = dp(4);
        bar.addView(addrWrap, ap);

        FrameLayout tw = new FrameLayout(this);
        tabsBox = new View(this);
        tw.addView(tabsBox, new FrameLayout.LayoutParams(dp(21), dp(21), Gravity.CENTER));
        tabsBtn = new TextView(this);
        tabsBtn.setText("1"); tabsBtn.setTextSize(12); tabsBtn.setGravity(Gravity.CENTER);
        tabsBtn.setTypeface(Typeface.DEFAULT_BOLD);
        tw.addView(tabsBtn, new FrameLayout.LayoutParams(-1, -1));
        click(tw, v -> openPanel("tabs", ""));
        bar.addView(tw, bp);

        aiIcon = icon(R.drawable.ic_prism, v -> openPanel("agents", ""));
        aiIcon.setOnLongClickListener(v -> { haptic(); openPanel("page", "summary"); return true; });
        bar.addView(aiIcon, bp);
        bar.addView(icon(R.drawable.ic_more, this::showMenu), bp);
        return bar;
    }

    void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        String[] items = {"Новая вкладка", "Инкогнито-вкладка", "Добавить в закладки", "Режим чтения", "Кратко о странице",
                "Перевести страницу", "Спросить по странице", "Отправить в…", "Поручить дозвон", "Закладки", "История",
                "Загрузки", "Сохранённые анализы", "Связи и задачи", (tab() != null && tab().desktop) ? "Мобильная версия" : "Версия для ПК",
                "Обновить", "Настройки"};
        for (int i = 0; i < items.length; i++) m.getMenu().add(0, i, i, items[i]);
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 0: newTab(prefs.getString("home", "https://yandex.ru"), false); break;
                case 1: newTab(prefs.getString("home", "https://yandex.ru"), true); break;
                case 2: openPanel("bookmark-add", ""); break;
                case 3: openPanel("page", "reader"); break;
                case 4: openPanel("page", "summary"); break;
                case 5: openPanel("page", "translate"); break;
                case 6: openPanel("page", "chat"); break;
                case 7: openPanel("send", ""); break;
                case 8: openPanel("call", ""); break;
                case 9: openPanel("library", "bookmarks"); break;
                case 10: openPanel("library", "history"); break;
                case 11: openPanel("library", "downloads"); break;
                case 12: openPanel("library", "archive"); break;
                case 13: openPanel("links", ""); break;
                case 14: toggleDesktop(); break;
                case 15: if (tab() != null) tab().wv.reload(); break;
                case 16: openPanel("settings", ""); break;
            }
            return true;
        });
        m.show();
    }

    void haptic() {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (!prefs.getBoolean("haptic", true)) return;
            if (v != null) v.vibrate(VibrationEffect.createOneShot(12, 80));
            if (barView != null) { barView.setSoundEffectsEnabled(true); barView.playSoundEffect(SoundEffectConstants.CLICK); }
        } catch (Exception ignored) {}
    }

    // ---------- navigation ----------
    void go(String text) {
        text = text.trim();
        hideKeyboard();
        if (text.isEmpty()) return;
        if (text.startsWith("?")) {
            JSONObject a = new JSONObject();
            try { a.put("q", text.substring(1).trim()); a.put("auto", true); } catch (Exception ignored) {}
            openPanel("agents", a.toString());
            Tab t = tab(); if (t != null) address.setText(t.url);
            return;
        }
        String url;
        if (text.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = text;
        else if (!text.contains(" ") && (text.contains(".") || text.startsWith("localhost")) && Patterns.WEB_URL.matcher(text).matches()) url = "https://" + text;
        else {
            try { url = prefs.getString("search", "https://yandex.ru/search/?text=") + URLEncoder.encode(text, "UTF-8"); }
            catch (Exception e) { url = text; }
        }
        Tab t = tab();
        if (t == null) newTab(url, false); else t.wv.loadUrl(url);
        if (t != null) t.wv.requestFocus();
    }

    void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    Tab tab() { return (cur >= 0 && cur < tabs.size()) ? tabs.get(cur) : null; }

    Tab newTab(String url, boolean incognito) {
        Tab t = new Tab();
        t.incognito = incognito;
        t.wv = makeWebView(t);
        tabs.add(t);
        content.addView(t.wv, new FrameLayout.LayoutParams(-1, -1));
        switchTo(tabs.size() - 1);
        if (url != null && !url.isEmpty()) { t.url = url; t.wv.loadUrl(url); }
        return t;
    }

    void switchTo(int i) {
        if (i < 0 || i >= tabs.size()) return;
        cur = i;
        for (int k = 0; k < tabs.size(); k++) {
            WebView w = tabs.get(k).wv;
            w.setVisibility(k == i ? View.VISIBLE : View.GONE);
            if (k == i) w.onResume(); else w.onPause();
        }
        Tab t = tabs.get(i);
        address.setText(t.url);
        incogDot.setVisibility(t.incognito ? View.VISIBLE : View.GONE);
        tabsBtn.setText(String.valueOf(tabs.size()));
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab t = tabs.remove(i);
        content.removeView(t.wv);
        if (t.incognito) t.wv.clearCache(true);
        t.wv.destroy();
        if (tabs.isEmpty()) { cur = -1; newTab(prefs.getString("home", "https://yandex.ru"), false); return; }
        switchTo(Math.min(i, tabs.size() - 1));
        boolean anyIncog = false;
        for (Tab x : tabs) anyIncog |= x.incognito;
        if (t.incognito && !anyIncog) { CookieManager.getInstance().removeSessionCookies(null); }
    }

    void toggleDesktop() {
        Tab t = tab(); if (t == null) return;
        t.desktop = !t.desktop;
        WebSettings s = t.wv.getSettings();
        s.setUserAgentString(t.desktop ? DESKTOP_UA : null);
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true);
        t.wv.reload();
    }

    WebView makeWebView(Tab t) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        if (t.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !prefs.getBoolean("block3p", true));
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl(); String sc = u.getScheme() == null ? "" : u.getScheme();
                if (sc.equals("http") || sc.equals("https") || sc.equals("about") || sc.equals("data") || sc.equals("blob")) return false;
                if (sc.equals("tel")) {
                    JSONObject a = new JSONObject();
                    try { a.put("phone", u.getSchemeSpecificPart()); } catch (Exception ignored) {}
                    openPanel("call", a.toString()); return true;
                }
                try {
                    Intent i = sc.equals("intent") ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, u);
                    i.addCategory(Intent.CATEGORY_BROWSABLE);
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                        String fb = i.getStringExtra("browser_fallback_url");
                        if (fb != null) v.loadUrl(fb);
                    } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame() && adblock.isBlocked(r.getUrl().getHost()))
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                return null;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                t.url = url;
                if (t == tab() && !address.hasFocus()) address.setText(url);
            }
            @Override public void onPageFinished(WebView v, String url) {
                t.url = url; t.title = v.getTitle() == null ? "" : v.getTitle();
                if (t == tab()) { if (!address.hasFocus()) address.setText(url); progress.setProgress(0); }
                if (!t.incognito && url.startsWith("http")) {
                    panelJs("App.onVisit(" + q(url) + "," + q(t.title) + ")");
                    prefs.edit().putString("lastUrl", url).apply();
                }
                if (t.pendingAgents != null) { String a = t.pendingAgents; t.pendingAgents = null; openPanel("agents", a); }
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { if (t == tab()) progress.setProgress(p >= 100 ? 0 : p); }
            @Override public void onReceivedTitle(WebView v, String title) { t.title = title; }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 77); } catch (Exception e) { fileCb = null; return false; }
                return true;
            }
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                customView = view; customCb = cb;
                fullscreenHolder.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenHolder.setVisibility(View.VISIBLE);
            }
            @Override public void onHideCustomView() { exitFullscreen(); }
        });
        w.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                String name = URLUtil.guessFileName(url, cd, mime);
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) r.addRequestHeader("Cookie", ck);
                r.addRequestHeader("User-Agent", ua);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Загружается: " + name, Toast.LENGTH_SHORT).show();
                panelJs("App.onDownload(" + q(name) + "," + q(url) + "," + len + ")");
            } catch (Exception e) {
                Toast.makeText(this, "Не удалось начать загрузку", Toast.LENGTH_SHORT).show();
            }
        });
        return w;
    }

    void exitFullscreen() {
        if (customView == null) return;
        fullscreenHolder.removeView(customView);
        fullscreenHolder.setVisibility(View.GONE);
        if (customCb != null) customCb.onCustomViewHidden();
        customView = null; customCb = null;
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 77 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    // ---------- panel ----------
    void setupPanel() {
        WebSettings s = panel.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        panel.addJavascriptInterface(new Bridge(), "Native");
        panel.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                panelReady = true;
                for (String js : panelQueue) panel.evaluateJavascript(js, null);
                panelQueue.clear();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http")) { closePanel(); newTab(u, false); }
                return true;
            }
        });
        panel.setWebChromeClient(new WebChromeClient());
        panel.loadUrl("file:///android_asset/panel.html");
    }

    void panelJs(String js) {
        ui.post(() -> { if (panelReady) panel.evaluateJavascript(js, null); else panelQueue.add(js); });
    }

    void openPanel(String route, String arg) {
        ui.post(() -> {
            hideKeyboard();
            panel.setVisibility(View.VISIBLE);
            panelOpen = true;
            panelJs("App.open(" + q(route) + "," + q(arg) + ")");
        });
    }

    void closePanel() {
        ui.post(() -> { panel.setVisibility(View.GONE); panelOpen = false; });
    }

    @Override public void onBackPressed() {
        if (customView != null) { exitFullscreen(); return; }
        if (panelOpen) { panelJs("App.back()"); return; }
        Tab t = tab();
        if (t != null && t.wv.canGoBack()) { t.wv.goBack(); return; }
        super.onBackPressed();
    }

    // ---------- intents ----------
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); handleIntent(i); }

    boolean handleIntent(Intent i) {
        if (i == null) return false;
        String act = i.getAction();
        try {
            if (Intent.ACTION_VIEW.equals(act) && i.getData() != null) {
                Uri u = i.getData();
                if ("prisma".equals(u.getScheme())) {
                    String host = u.getHost() == null ? "" : u.getHost();
                    String url = u.getQueryParameter("url");
                    JSONObject a = new JSONObject();
                    for (String k : u.getQueryParameterNames()) a.put(k, u.getQueryParameter(k));
                    if (host.equals("open")) { if (url != null) newTab(url, false); else if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false); }
                    else if (host.equals("analyze") || host.equals("ask")) {
                        a.put("auto", !"0".equals(u.getQueryParameter("auto")));
                        if (url != null) { Tab t = newTab(url, false); t.pendingAgents = a.toString(); }
                        else { if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false); openPanel("agents", a.toString()); }
                    } else if (host.equals("links")) {
                        if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false);
                        openPanel("links", "");
                    } else return false;
                    return true;
                }
                newTab(u.toString(), false);
                return true;
            }
            if (Intent.ACTION_SEND.equals(act)) {
                String text = i.getStringExtra(Intent.EXTRA_TEXT);
                if (text == null) return false;
                String subj = i.getStringExtra(Intent.EXTRA_SUBJECT);
                Matcher m = Patterns.WEB_URL.matcher(text);
                String url = null;
                while (m.find()) { String g = m.group(); if (g.startsWith("http")) { url = g; break; } }
                JSONObject a = new JSONObject();
                a.put("q", ""); a.put("shared", (subj != null ? subj + "\n" : "") + text); a.put("auto", false);
                if (url != null) { Tab t = newTab(url, false); t.pendingAgents = a.toString(); }
                else { if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false); openPanel("agents", a.toString()); }
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    @Override protected void onPause() { super.onPause(); Tab t = tab(); if (t != null) t.wv.onPause(); CookieManager.getInstance().flush(); }
    @Override protected void onResume() { super.onResume(); Tab t = tab(); if (t != null) t.wv.onResume(); }

    static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toString("UTF-8");
    }

    // ---------- JS bridge for panel ----------
    class Bridge {
        @JavascriptInterface public void http(String id, String method, String url, String headersJson, String body, int timeoutSec) {
            new Thread(() -> {
                int code = 0; String resp;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(Math.max(30, timeoutSec) * 1000);
                    if (headersJson != null && !headersJson.isEmpty()) {
                        JSONObject h = new JSONObject(headersJson);
                        for (Iterator<String> it = h.keys(); it.hasNext(); ) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }
                    }
                    if (body != null && !body.isEmpty() && !method.equals("GET")) {
                        c.setDoOutput(true);
                        try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                    }
                    code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    resp = in == null ? "" : readAll(in);
                } catch (Exception e) { resp = "NETWORK: " + e.getClass().getSimpleName() + ": " + e.getMessage(); }
                panelJs("App._httpDone(" + q(id) + "," + code + "," + q(resp) + ")");
            }).start();
        }

        @JavascriptInterface public void pageText(String id, int index) {
            ui.post(() -> {
                int i = index < 0 ? cur : index;
                if (i < 0 || i >= tabs.size()) { panelJs("App._pageText(" + q(id) + ",null)"); return; }
                WebView w = tabs.get(i).wv;
                w.onResume();
                w.evaluateJavascript(extractJs, v -> {
                    if (i != cur) w.onPause();
                    panelJs("App._pageText(" + q(id) + "," + (v == null ? "null" : v) + ")");
                });
            });
        }

        @JavascriptInterface public String tabs() {
            JSONArray a = new JSONArray();
            try {
                for (int i = 0; i < tabs.size(); i++) {
                    Tab t = tabs.get(i);
                    JSONObject o = new JSONObject();
                    o.put("i", i); o.put("url", t.url); o.put("title", t.title); o.put("incognito", t.incognito); o.put("current", i == cur);
                    a.put(o);
                }
            } catch (Exception ignored) {}
            return a.toString();
        }

        @JavascriptInterface public String current() {
            JSONObject o = new JSONObject();
            try { Tab t = tab(); if (t != null) { o.put("url", t.url); o.put("title", t.title); o.put("incognito", t.incognito); o.put("i", cur); } } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface public void switchTab(int i) { ui.post(() -> { switchTo(i); closePanel(); }); }
        @JavascriptInterface public void closeTab(int i) { ui.post(() -> { MainActivity.this.closeTab(i); panelJs("App.refresh()"); }); }
        @JavascriptInterface public void newTab(String url, boolean incognito) { ui.post(() -> { MainActivity.this.newTab(url == null || url.isEmpty() ? prefs.getString("home", "https://yandex.ru") : url, incognito); closePanel(); }); }
        @JavascriptInterface public void open(String url) { ui.post(() -> { Tab t = tab(); if (t == null) MainActivity.this.newTab(url, false); else t.wv.loadUrl(url); closePanel(); }); }
        @JavascriptInterface public void closePanel() { MainActivity.this.closePanel(); }
        @JavascriptInterface public void toast(String m) { ui.post(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show()); }
        @JavascriptInterface public void haptic() { ui.post(MainActivity.this::haptic); }

        @JavascriptInterface public void copy(String text) {
            ui.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Призма", text));
                Toast.makeText(MainActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
            });
        }

        /** Share text; pkg empty = system chooser. Returns false if pkg not installed. */
        @JavascriptInterface public boolean share(String text, String subject, String pkg) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                if (subject != null && !subject.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.putExtra("prisma.source", "prisma");
                if (pkg != null && !pkg.isEmpty()) {
                    i.setPackage(pkg);
                    if (i.resolveActivity(getPackageManager()) == null) return false;
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } else startActivity(Intent.createChooser(i, "Отправить"));
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public boolean launch(String pkg) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return false;
                startActivity(i); return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public boolean installed(String pkg) {
            try { return getPackageManager().getLaunchIntentForPackage(pkg) != null; } catch (Exception e) { return false; }
        }

        @JavascriptInterface public boolean openUri(String uri) {
            try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface public void dial(String phone) {
            ui.post(() -> { try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone)))); } catch (Exception ignored) {} });
        }

        @JavascriptInterface public void config(String json) {
            try {
                JSONObject o = new JSONObject(json);
                SharedPreferences.Editor e = prefs.edit();
                if (o.has("home")) e.putString("home", o.getString("home"));
                if (o.has("search")) e.putString("search", o.getString("search"));
                if (o.has("haptic")) e.putBoolean("haptic", o.getBoolean("haptic"));
                if (o.has("block3p")) e.putBoolean("block3p", o.getBoolean("block3p"));
                if (o.has("adblock")) { e.putBoolean("adblock", o.getBoolean("adblock")); adblock.enabled = o.getBoolean("adblock"); }
                e.apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public String adblockInfo() {
            return "{\"enabled\":" + adblock.enabled + ",\"hosts\":" + adblock.size() + ",\"blocked\":" + adblock.blockedCount + "}";
        }

        @JavascriptInterface public void adblockUpdate(String id, String url) {
            new Thread(() -> { int n = adblock.download(url); panelJs("App._adblockDone(" + q(id) + "," + n + ")"); }).start();
        }

        @JavascriptInterface public void clearData(String what) {
            ui.post(() -> {
                if (what.contains("cookies")) { CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); }
                if (what.contains("cache")) for (Tab t : tabs) t.wv.clearCache(true);
                if (what.contains("storage")) WebStorage.getInstance().deleteAllData();
                Toast.makeText(MainActivity.this, "Очищено", Toast.LENGTH_SHORT).show();
            });
        }

        /** Saves a text file into Downloads/Prisma. */
        @JavascriptInterface public boolean saveFile(String name, String text, String mime) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Prisma");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (u == null) return false;
                    try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
                    ui.post(() -> Toast.makeText(MainActivity.this, "Сохранено в Загрузки/Prisma", Toast.LENGTH_SHORT).show());
                    return true;
                }
            } catch (Exception ignored) {}
            return false;
        }

        @JavascriptInterface public void setTheme(String mode) {
            ui.post(() -> {
                boolean d = "dark".equals(mode);
                prefs.edit().putString("theme", mode).apply();
                if (d == dark) return;
                dark = d; pickColors(); applyColors();
            });
        }

        @JavascriptInterface public void setAddress(String text) { ui.post(() -> address.setText(text)); }
    }
}
