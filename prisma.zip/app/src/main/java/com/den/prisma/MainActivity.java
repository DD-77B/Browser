package com.den.prisma;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.os.CancellationSignal;
import android.view.MotionEvent;
import android.app.role.RoleManager;
import android.provider.Settings;
import android.webkit.PermissionRequest;
import android.speech.tts.TextToSpeech;
import android.content.pm.PackageManager;
import android.util.Base64;
import java.util.Locale;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.res.ColorStateList;
import android.view.SoundEffectConstants;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;

public class MainActivity extends Activity {

    static class Tab {
        WebView wv; boolean incognito; boolean desktop;
        String url = ""; String title = ""; String pendingAgents = null;
        int uid; boolean translating = false; String trHost = null, trAsked = null; int trLeft = 0;
        boolean report = false; String formsFor = null; String pendingUrl = null; Bitmap thumb = null; boolean pendingLogin = false; String loginId = null; int loginSteps = 0; String bannerFor = null;
    }

    final List<Tab> tabs = new ArrayList<>();
    int cur = -1;
    FrameLayout stack, content, fullscreenHolder;
    WebView panel;
    boolean panelReady = false, panelOpen = false;
    final List<String> panelQueue = new ArrayList<>();
    EditText address;
    TextView tabsBtn, incogDot;
    ProgressBar progress;
    AdBlock adblock;
    SharedPreferences prefs;
    String extractJs = "";
    ValueCallback<Uri[]> fileCb;
    View customView; WebChromeClient.CustomViewCallback customCb;
    final Handler ui = new Handler(Looper.getMainLooper());
    boolean dark;
    int cBar, cText, cField, cAccent, cMute;
    LinearLayout rootView, barView;
    final List<ImageView> icons = new ArrayList<>();
    View tabsBox; ImageView aiIcon;
    PermissionRequest pendingMic;
    Vault vault; String hookJs = "", fillJs = "", pfJs = "", trJs = "";
    final java.util.Map<String, Tab> trReqs = new java.util.HashMap<>(); int tabSeq = 0; long unlockedUntil = 0; Runnable pendingAuth;
    boolean inFront = false;
    Uri photoUri; String pendingPhotoId; Runnable pendingPerm; PermissionRequest pendingWebPerm; String[] pendingWebRes;
    LinearLayout banner; String lastOffer = ""; long lastOfferAt = 0;
    float swX, swY; int swEdge = 0; boolean swiping = false; TextView swipeHint;
    TextToSpeech tts; boolean ttsReady = false;

    static final String DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";

    int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("prisma", MODE_PRIVATE);
        String th = prefs.getString("theme", "auto");
        dark = th.equals("dark") || (!th.equals("light") && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        pickColors();

        try (InputStream in = getAssets().open("extract.js")) { extractJs = readAll(in); } catch (Exception ignored) {}
        try (InputStream in = getAssets().open("vault_hook.js")) { hookJs = readAll(in); } catch (Exception ignored) {}
        try (InputStream in = getAssets().open("vault_fill.js")) { fillJs = readAll(in); } catch (Exception ignored) {}
        try (InputStream in = getAssets().open("profile_fill.js")) { pfJs = readAll(in); } catch (Exception ignored) {}
        try (InputStream in = getAssets().open("translate.js")) { trJs = readAll(in); } catch (Exception ignored) {}
        vault = new Vault(this);
        adblock = new AdBlock(this);
        adblock.enabled = prefs.getBoolean("adblock", true);
        adblock.loadAsync();
        tts = new TextToSpeech(this, st -> ttsReady = st == TextToSpeech.SUCCESS);

        LinearLayout root = new LinearLayout(this);
        rootView = root;
        root.setOrientation(LinearLayout.VERTICAL);

        stack = new FrameLayout(this);
        content = new FrameLayout(this);
        content.setBackgroundColor(Color.WHITE);
        stack.addView(content, new FrameLayout.LayoutParams(-1, -1));
        panel = new WebView(this);
        panel.setVisibility(View.GONE);
        stack.addView(panel, new FrameLayout.LayoutParams(-1, -1));
        fullscreenHolder = new FrameLayout(this);
        fullscreenHolder.setBackgroundColor(Color.BLACK);
        fullscreenHolder.setVisibility(View.GONE);
        stack.addView(fullscreenHolder, new FrameLayout.LayoutParams(-1, -1));
        swipeHint = new TextView(this);
        swipeHint.setText("‹"); swipeHint.setTextSize(30); swipeHint.setTextColor(Color.WHITE);
        swipeHint.setGravity(Gravity.CENTER); swipeHint.setPadding(0, 0, dp(3), dp(4));
        GradientDrawable sh = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#7A5AFD"), Color.parseColor("#4929C9")});
        sh.setShape(GradientDrawable.OVAL);
        swipeHint.setBackground(sh); swipeHint.setElevation(dp(6)); swipeHint.setAlpha(0f);
        stack.addView(swipeHint, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START | Gravity.CENTER_VERTICAL));
        banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setPadding(dp(16), dp(12), dp(10), dp(6));
        banner.setElevation(dp(8));
        banner.setVisibility(View.GONE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        blp.setMargins(dp(10), 0, dp(10), dp(10));
        stack.addView(banner, blp);
        buildStrip();
        root.addView(stack, new LinearLayout.LayoutParams(-1, 0, 1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));
        root.addView(buildToolbar(), new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        applyColors();

        setupPanel();
        if (!prefs.getBoolean("askedDefault", false)) {
            prefs.edit().putBoolean("askedDefault", true).apply();
            ui.postDelayed(() -> { if (!isDefaultBrowser()) requestDefaultBrowser(); }, 1800);
        }
        restoreTabs();
        if (!handleIntent(getIntent()) && tabs.isEmpty()) {
            String last = prefs.getString("lastUrl", "");
            newTab(last.isEmpty() ? prefs.getString("home", "https://yandex.ru") : last, false);
        }
    }

    // ---------- toolbar (same look as SWS / Smart Bubbles: iOS-style bar, violet accent, line icons) ----------
    void pickColors() {
        // Smart Bubbles palette
        cAccent = dark ? Color.parseColor("#8B72FF") : Color.parseColor("#6A4AF0");
        cBar = dark ? Color.BLACK : Color.parseColor("#F2F2F7");
        cText = dark ? Color.WHITE : Color.BLACK;
        cField = dark ? Color.parseColor("#1C1C1E") : Color.parseColor("#E4E4E9");
        cMute = Color.parseColor("#8E8E93");
    }

    void applyColors() {
        getWindow().setStatusBarColor(cBar);
        getWindow().setNavigationBarColor(cBar);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
        rootView.setBackgroundColor(cBar);
        barView.setBackgroundColor(cBar);
        for (ImageView iv : icons) iv.setImageTintList(ColorStateList.valueOf(cAccent));
        address.setTextColor(cText);
        address.setHintTextColor(cMute);
        GradientDrawable g = new GradientDrawable();
        g.setColor(dark ? Color.parseColor("#1C1C1E") : Color.WHITE); g.setCornerRadius(dp(29));
        pill.setBackground(g);
        GradientDrawable mg = new GradientDrawable();
        mg.setShape(GradientDrawable.OVAL);
        mg.setColor(dark ? Color.argb(46, 139, 114, 255) : Color.argb(31, 106, 74, 240));
        pillMic.setBackground(mg);
        pillMic.setImageTintList(ColorStateList.valueOf(cAccent));
        GradientDrawable tg = new GradientDrawable();
        tg.setStroke(dp(2), cAccent); tg.setCornerRadius(dp(6));
        tabsBox.setBackground(tg);
        tabsBtn.setTextColor(cAccent);
        incogDot.setTextColor(cAccent);
        siteLabel.setTextColor(cText);
        cancelBtn.setTextColor(cAccent);
        inputRow.setBackgroundColor(cBar);
        progress.setProgressTintList(ColorStateList.valueOf(cAccent));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(cBar));
        panel.setBackgroundColor(cBar);
    }

    View click(View v, View.OnClickListener l) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true);
        v.setBackgroundResource(tv.resourceId);
        v.setOnClickListener(x -> { haptic(); l.onClick(x); });
        return v;
    }

    ImageView icon(int res, View.OnClickListener l) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        icons.add(iv);
        click(iv, l);
        return iv;
    }

    LinearLayout inputRow, pill; TextView siteLabel, cancelBtn, pillGo; ImageView pillMic;

    /** Toolbar: [tabs][site name] — [voice, centred] — [✦][⋮]; tapping the site name opens the address input above it. */
    View buildToolbar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        // address input: Smart Bubbles "pill" — [✦ gradient circle = go] [text] [mic circle], grows out of the circle
        inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(dp(12), dp(10), dp(12), dp(4));
        inputRow.setClipChildren(false); inputRow.setClipToPadding(false);
        inputRow.setVisibility(View.GONE);
        pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(9), 0, dp(7), 0);
        pill.setElevation(dp(6));
        pillGo = new TextView(this);
        pillGo.setText("✦"); pillGo.setTextSize(19); pillGo.setTextColor(Color.WHITE); pillGo.setGravity(Gravity.CENTER);
        GradientDrawable pg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#7A5AFD"), Color.parseColor("#4929C9")});
        pg.setShape(GradientDrawable.OVAL);
        pillGo.setBackground(pg);
        click(pillGo, v -> submitInput());
        pill.addView(pillGo, new LinearLayout.LayoutParams(dp(40), dp(40)));
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextSize(16);
        address.setHint("Сайт или вопрос агенту");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setSelectAllOnFocus(true);
        address.setBackground(null);
        address.setPadding(dp(10), 0, dp(6), 0);
        address.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_GO || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { submitInput(); return true; }
            return false;
        });
        address.setOnFocusChangeListener((v, has) -> { if (!has && inputRow.getVisibility() == View.VISIBLE) ui.postDelayed(() -> { if (!address.hasFocus()) closeInput(); }, 120); });
        pill.addView(address, new LinearLayout.LayoutParams(0, -1, 1));
        pillMic = new ImageView(this);
        pillMic.setImageResource(R.drawable.ic_mic);
        pillMic.setScaleType(ImageView.ScaleType.CENTER);
        click(pillMic, v -> { closeInput(); openPanel("agent", "{\"voice\":true}"); });
        pill.addView(pillMic, new LinearLayout.LayoutParams(dp(44), dp(44)));
        inputRow.addView(pill, new LinearLayout.LayoutParams(-1, dp(58)));
        cancelBtn = new TextView(this); // not shown; closing is by Back or tapping outside
        wrap.addView(inputRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout bar = new LinearLayout(this);
        barView = bar;
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), 0, dp(4), 0);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(42), dp(48));

        // left half: tabs in the very corner + site name
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout tw = new FrameLayout(this);
        tabsBox = new View(this);
        tw.addView(tabsBox, new FrameLayout.LayoutParams(dp(21), dp(21), Gravity.CENTER));
        tabsBtn = new TextView(this);
        tabsBtn.setText("1"); tabsBtn.setTextSize(12); tabsBtn.setGravity(Gravity.CENTER);
        tabsBtn.setTypeface(Typeface.DEFAULT_BOLD);
        tw.addView(tabsBtn, new FrameLayout.LayoutParams(-1, -1));
        click(tw, v -> openPanel("tabs", ""));
        left.addView(tw, bp);
        siteLabel = new TextView(this);
        siteLabel.setTextSize(15);
        siteLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        siteLabel.setSingleLine(true);
        siteLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        siteLabel.setGravity(Gravity.CENTER_VERTICAL);
        siteLabel.setPadding(dp(6), 0, dp(8), 0);
        click(siteLabel, v -> openInput());
        left.addView(siteLabel, new LinearLayout.LayoutParams(0, dp(48), 1));
        incogDot = new TextView(this); // kept for colours; incognito is shown as a prefix in the site name
        bar.addView(left, new LinearLayout.LayoutParams(0, -1, 1));

        // centre: large voice button (same gradient circle as the Smart Bubbles FAB)
        ImageView mic = new ImageView(this);
        mic.setImageResource(R.drawable.ic_mic);
        mic.setScaleType(ImageView.ScaleType.CENTER);
        mic.setImageTintList(ColorStateList.valueOf(Color.WHITE));
        GradientDrawable mg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#7A5AFD"), Color.parseColor("#4929C9")});
        mg.setShape(GradientDrawable.OVAL);
        mic.setBackground(mg);
        mic.setElevation(dp(5));
        mic.setScaleX(1.15f); mic.setScaleY(1.15f);
        // as in Smart Bubbles: tap = voice, hold = text; the button shrinks while held
        mic.setOnTouchListener((v, ev) -> {
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) v.animate().scaleX(1.03f).scaleY(1.03f).setDuration(120).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(150).start();
            return false;
        });
        mic.setOnClickListener(v -> {
            haptic(); openPanel("agent", "{\"voice\":true}");
            if (!prefs.getBoolean("micHint", false)) {
                prefs.edit().putBoolean("micHint", true).apply();
                ui.postDelayed(() -> Toast.makeText(this, "Подсказка: удерживай кнопку, чтобы написать текстом", Toast.LENGTH_LONG).show(), 1500);
            }
        });
        mic.setOnLongClickListener(v -> {
            try { ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).vibrate(VibrationEffect.createOneShot(25, 120)); } catch (Exception ignored) {}
            openPanel("agent", "{\"text\":true}"); return true;
        });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(50), dp(50));
        mp.leftMargin = dp(6); mp.rightMargin = dp(6);
        bar.addView(mic, mp);

        // right half: analysis + menu, pushed to the right edge
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.HORIZONTAL);
        right.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        aiIcon = icon(R.drawable.ic_prism, v -> openPanel("agents", ""));
        aiIcon.setOnLongClickListener(v -> { haptic(); openPanel("page", "summary"); return true; });
        right.addView(aiIcon, bp);
        right.addView(icon(R.drawable.ic_more, this::showMenu), bp);
        bar.addView(right, new LinearLayout.LayoutParams(0, -1, 1));

        wrap.addView(bar, new LinearLayout.LayoutParams(-1, dp(68)));
        return wrap;
    }

    static String siteName(String url) {
        if (url == null || url.isEmpty() || url.startsWith("about:")) return "Новая вкладка";
        try {
            String h = Uri.parse(url).getHost();
            if (h == null || h.isEmpty()) return url;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return url; }
    }

    static final String REPORT_BASE = "https://prisma.report/";

    void showUrl(String url) {
        Tab t = tab();
        String num = tabs.size() > 1 ? (cur + 1) + " · " : "";
        if (t != null && t.report) { if (!address.hasFocus()) address.setText(""); siteLabel.setText(num + "✦ " + t.title); return; }
        if (!address.hasFocus()) address.setText(url);
        siteLabel.setText(num + ((t != null && t.incognito) ? "◐ " : "") + ((t != null && t.translating) ? (t.trLeft > 0 ? "⟳ " : "文→ ") : "") + siteName(url));
    }

    void openInput() {
        Tab t = tab();
        address.setText(t != null ? t.url : "");
        inputRow.setVisibility(View.VISIBLE);
        // the pill grows out of its ✦ circle
        pill.setPivotX(dp(29)); pill.setPivotY(dp(29));
        pill.setScaleX(0.14f); pill.setAlpha(0f);
        address.setAlpha(0f); pillMic.setAlpha(0f);
        pillGo.setRotation(-90f);
        pill.animate().scaleX(1f).alpha(1f).setDuration(280).setInterpolator(new android.view.animation.DecelerateInterpolator(2f)).start();
        pillGo.animate().rotation(0f).setDuration(280).start();
        address.animate().alpha(1f).setStartDelay(140).setDuration(160).start();
        pillMic.animate().alpha(1f).setStartDelay(180).setDuration(160).start();
        // ask the keyboard for the English layout in the address line (Gboard, SwiftKey and most others honour this)
        address.setImeHintLocales(prefs.getBoolean("addrEnglish", true) ? new android.os.LocaleList(Locale.ENGLISH) : null);
        address.requestFocus();
        address.selectAll();
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null) address.postDelayed(() -> { im.restartInput(address); im.showSoftInput(address, InputMethodManager.SHOW_IMPLICIT); }, 60);
    }

    void submitInput() {
        String txt = address.getText().toString().trim();
        if (txt.isEmpty()) { closeInput(); return; }
        closeInput();
        go(txt);
    }

    void closeInput() {
        if (inputRow.getVisibility() != View.VISIBLE) return;
        hideKeyboard();
        pill.animate().scaleX(0.14f).alpha(0f).setStartDelay(0).setDuration(180)
            .withEndAction(() -> { inputRow.setVisibility(View.GONE); pill.setScaleX(1f); pill.setAlpha(1f); }).start();
        Tab t = tab(); if (t != null) showUrl(t.url);
    }

    void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        String[] items = {"Вперёд", "Новая вкладка", "Инкогнито-вкладка", "Добавить в закладки", "Режим чтения", "Кратко о странице",
                (tab() != null && tab().translating) ? "Показать оригинал" : "Перевести страницу", "Спросить по странице", "Отправить в…", "Поручить дозвон", "Закладки", "История",
                "Загрузки", "Сохранённые анализы", "Связи и задачи", (tab() != null && tab().desktop) ? "Мобильная версия" : "Версия для ПК",
                "Обновить", "Настройки", "Пароли", "Заполнить мои данные"};
        for (int i = 0; i < items.length; i++) m.getMenu().add(0, i, i, items[i]);
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId() - 1) {
                case -1: { Tab t = tab(); if (t != null && t.wv.canGoForward()) t.wv.goForward(); break; }
                case 0: newTab(prefs.getString("home", "https://yandex.ru"), false); break;
                case 1: newTab(prefs.getString("home", "https://yandex.ru"), true); break;
                case 2: openPanel("bookmark-add", ""); break;
                case 3: openPanel("page", "reader"); break;
                case 4: openPanel("page", "summary"); break;
                case 5: { Tab t = tab(); if (t != null) { if (t.translating) stopTranslate(t); else startTranslate(t); } break; }
                case 6: openPanel("page", "chat"); break;
                case 7: openPanel("send", ""); break;
                case 8: openPanel("call", ""); break;
                case 9: openPanel("library", "bookmarks"); break;
                case 10: openPanel("library", "history"); break;
                case 11: openPanel("library", "downloads"); break;
                case 12: openPanel("library", "archive"); break;
                case 13: openPanel("links", ""); break;
                case 14: toggleDesktop(); break;
                case 15: if (tab() != null) tab().wv.reload(); break;
                case 16: openPanel("settings", ""); break;
                case 17: openPanel("passwords", ""); break;
                case 18: if (tab() != null) fillProfile(tab(), false, null, null); break;
            }
            return true;
        });
        m.show();
    }

    void haptic() {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (!prefs.getBoolean("haptic", true)) return;
            if (v != null) v.vibrate(VibrationEffect.createOneShot(12, 80));
            if (barView != null) { barView.setSoundEffectsEnabled(true); barView.playSoundEffect(SoundEffectConstants.CLICK); }
        } catch (Exception ignored) {}
    }

    // ---------- navigation ----------
    void go(String text) {
        text = text.trim();
        hideKeyboard();
        if (text.isEmpty()) return;
        if (text.startsWith("?")) {
            JSONObject a = new JSONObject();
            try { a.put("q", text.substring(1).trim()); a.put("auto", true); } catch (Exception ignored) {}
            openPanel("agents", a.toString());
            Tab t = tab(); if (t != null) showUrl(t.url);
            return;
        }
        boolean classic = text.startsWith("!");
        if (classic) text = text.substring(1).trim();
        String url;
        if (text.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = text;
        else if (!text.contains(" ") && (text.contains(".") || text.startsWith("localhost")) && Patterns.WEB_URL.matcher(text).matches()) url = "https://" + text;
        else if (!classic && prefs.getString("searchMode", "ai").equals("ai")) {
            JSONObject a = new JSONObject();
            try { a.put("q", text); a.put("mode", "search"); } catch (Exception ignored) {}
            openPanel("agent", a.toString());
            Tab t = tab(); if (t != null) showUrl(t.url);
            return;
        }
        else {
            try { url = prefs.getString("search", "https://yandex.ru/search/?text=") + URLEncoder.encode(text, "UTF-8"); }
            catch (Exception e) { url = text; }
        }
        Tab t = tab();
        if (t == null) newTab(url, false); else t.wv.loadUrl(url);
        if (t != null) t.wv.requestFocus();
    }

    void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    Tab tab() { return (cur >= 0 && cur < tabs.size()) ? tabs.get(cur) : null; }

    Tab newTab(String url, boolean incognito) {
        Tab t = new Tab();
        t.incognito = incognito;
        t.wv = makeWebView(t);
        tabs.add(t);
        content.addView(t.wv, new FrameLayout.LayoutParams(-1, -1));
        switchTo(tabs.size() - 1);
        if (url != null && !url.isEmpty()) { t.url = url; t.wv.loadUrl(url); }
        return t;
    }

    void switchTo(int i) {
        if (i < 0 || i >= tabs.size()) return;
        if (cur >= 0 && cur < tabs.size() && cur != i) snapshot(tabs.get(cur));
        cur = i;
        for (int k = 0; k < tabs.size(); k++) {
            WebView w = tabs.get(k).wv;
            w.setVisibility(k == i ? View.VISIBLE : View.GONE);
            if (k == i) w.onResume(); else w.onPause();
        }
        Tab t = tabs.get(i);
        if (t.pendingUrl != null) { String u = t.pendingUrl; t.pendingUrl = null; t.wv.loadUrl(u); }
        showUrl(t.url);
        tabsBtn.setText(String.valueOf(tabs.size()));
        saveTabsSoon();
    }

    // ---------- tabs survive restarts ----------
    final Runnable saveTabsR = this::saveTabs;
    void saveTabsSoon() { ui.removeCallbacks(saveTabsR); ui.postDelayed(saveTabsR, 800); }
    void saveTabs() {
        try {
            JSONArray a = new JSONArray(); int c = 0, k = 0;
            for (int i = 0; i < tabs.size(); i++) {
                Tab t = tabs.get(i);
                if (t.incognito || t.report || t.url == null || !t.url.startsWith("http")) continue;
                JSONObject o = new JSONObject(); o.put("url", t.url); o.put("title", t.title); a.put(o);
                if (i == cur) c = k; k++;
            }
            prefs.edit().putString("tabs", a.toString()).putInt("tabCur", c).apply();
        } catch (Exception ignored) {}
    }
    void restoreTabs() {
        try {
            JSONArray a = new JSONArray(prefs.getString("tabs", "[]"));
            if (a.length() == 0) return;
            int c = Math.min(prefs.getInt("tabCur", 0), a.length() - 1);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Tab t = new Tab();
                t.wv = makeWebView(t);
                t.url = o.optString("url"); t.title = o.optString("title");
                t.pendingUrl = t.url;               // loaded only when opened
                t.wv.setVisibility(View.GONE);
                tabs.add(t);
                content.addView(t.wv, new FrameLayout.LayoutParams(-1, -1));
            }
            switchTo(c);
        } catch (Exception ignored) {}
    }

    void snapshot(Tab t) {
        try {
            if (t.wv.getWidth() == 0 || t.wv.getVisibility() != View.VISIBLE) return;
            float k = 0.33f;
            Bitmap b = Bitmap.createBitmap(Math.max(1, (int) (t.wv.getWidth() * k)), Math.max(1, (int) (t.wv.getHeight() * k * 0.6f)), Bitmap.Config.RGB_565);
            android.graphics.Canvas cv = new android.graphics.Canvas(b);
            cv.scale(k, k); cv.translate(0, -t.wv.getScrollY());
            t.wv.draw(cv);
            t.thumb = b;
        } catch (Throwable ignored) {}
    }

    // ---------- tab strip: swipe sideways on the bottom bar (or move the mouse to the left edge) ----------
    android.widget.HorizontalScrollView stripScroll; LinearLayout strip; int stripSel = -1; boolean stripOpen = false;
    void buildStrip() {
        stripScroll = new android.widget.HorizontalScrollView(this);
        stripScroll.setHorizontalScrollBarEnabled(false);
        stripScroll.setClipToPadding(false);
        stripScroll.setPadding(dp(12), dp(10), dp(12), dp(10));
        strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        stripScroll.addView(strip);
        stripScroll.setVisibility(View.GONE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        stack.addView(stripScroll, lp);
    }
    void showStrip(int sel) {
        if (stripScroll == null) return;
        Tab ct = tab(); if (ct != null) snapshot(ct);
        strip.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i; Tab t = tabs.get(i);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(8), dp(8), dp(8), dp(8));
            card.setElevation(dp(6));
            ImageView th = new ImageView(this);
            th.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable thb = new GradientDrawable(); thb.setCornerRadius(dp(10)); thb.setColor(dark ? Color.parseColor("#2C2C2E") : Color.parseColor("#E9E9EB"));
            th.setBackground(thb); th.setClipToOutline(true);
            if (t.thumb != null) th.setImageBitmap(t.thumb);
            card.addView(th, new LinearLayout.LayoutParams(-1, dp(84)));
            TextView nm = new TextView(this);
            nm.setText((i + 1) + " · " + (t.report ? "✦ " + t.title : siteName(t.url)));
            nm.setTextSize(13); nm.setTypeface(Typeface.DEFAULT_BOLD); nm.setTextColor(cText); nm.setSingleLine(true);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END); nm.setPadding(dp(2), dp(6), dp(2), 0);
            card.addView(nm);
            TextView tt = new TextView(this);
            tt.setText(t.title == null ? "" : t.title); tt.setTextSize(11.5f); tt.setTextColor(cMute); tt.setSingleLine(true);
            tt.setEllipsize(android.text.TextUtils.TruncateAt.END); tt.setPadding(dp(2), 0, dp(2), 0);
            card.addView(tt);
            card.setOnClickListener(v -> { haptic(); hideStrip(); switchTo(idx); });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(150), -2);
            cp.rightMargin = dp(10);
            strip.addView(card, cp);
        }
        // "+" card
        TextView plus = new TextView(this);
        plus.setText("+"); plus.setTextSize(30); plus.setGravity(Gravity.CENTER); plus.setTextColor(cAccent);
        GradientDrawable pb = new GradientDrawable(); pb.setCornerRadius(dp(16)); pb.setStroke(dp(2), cAccent);
        plus.setBackground(pb);
        plus.setOnClickListener(v -> { hideStrip(); newTab(prefs.getString("home", "https://yandex.ru"), false); });
        strip.addView(plus, new LinearLayout.LayoutParams(dp(70), dp(130)));
        stripOpen = true;
        stripScroll.setVisibility(View.VISIBLE);
        stripScroll.setAlpha(0f); stripScroll.setTranslationY(dp(40));
        stripScroll.animate().alpha(1f).translationY(0).setDuration(180).start();
        selectStrip(sel);
    }
    void selectStrip(int sel) {
        sel = Math.max(0, Math.min(tabs.size() - 1, sel));
        if (sel != stripSel && stripSel >= 0) haptic();
        stripSel = sel;
        for (int i = 0; i < strip.getChildCount() - 1; i++) {
            View c = strip.getChildAt(i);
            GradientDrawable bg = new GradientDrawable(); bg.setCornerRadius(dp(16));
            bg.setColor(dark ? Color.parseColor("#1C1C1E") : Color.WHITE);
            if (i == sel) bg.setStroke(dp(3), cAccent);
            else if (i == cur) bg.setStroke(dp(1), cMute);
            c.setBackground(bg);
            c.setScaleX(i == sel ? 1.04f : 1f); c.setScaleY(i == sel ? 1.04f : 1f);
        }
        final View target = strip.getChildAt(sel);
        if (target != null) stripScroll.post(() -> stripScroll.smoothScrollTo(Math.max(0, target.getLeft() - (stripScroll.getWidth() - target.getWidth()) / 2), 0));
    }
    void hideStrip() {
        if (!stripOpen) return;
        stripOpen = false;
        stripScroll.animate().alpha(0f).translationY(dp(30)).setDuration(150).withEndAction(() -> stripScroll.setVisibility(View.GONE)).start();
    }
    final Runnable hideStripR = this::hideStrip;

    float barX0; boolean barSwiping = false, barTracking = false;
    /** swipe left/right along the bottom bar: shows the tab cards and moves the highlight card by card; release = open */
    boolean barTouch(MotionEvent e) {
        if (tabs.size() < 2) return false;
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) { barX0 = e.getRawX(); barSwiping = false; return false; }
        if (a == MotionEvent.ACTION_MOVE) {
            float dx = e.getRawX() - barX0;
            if (!barSwiping && Math.abs(dx) > dp(24)) { barSwiping = true; ui.removeCallbacks(hideStripR); showStrip(cur); }
            if (barSwiping) { selectStrip(cur + Math.round(-dx / dp(56))); return true; }
        }
        if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && barSwiping) {
            barSwiping = false;
            int target = stripSel;
            if (a == MotionEvent.ACTION_UP && target != cur) switchTo(target);
            ui.postDelayed(hideStripR, a == MotionEvent.ACTION_UP && target == cur ? 3500 : 450);
            return true;
        }
        return barSwiping;
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
        // mouse / touchpad on the tablet: move the pointer to the left edge → tab cards
        if (e.isFromSource(android.view.InputDevice.SOURCE_MOUSE) && e.getActionMasked() == MotionEvent.ACTION_HOVER_MOVE && !panelOpen) {
            if (e.getX() <= dp(4) && !stripOpen && tabs.size() > 1) { showStrip(cur); ui.removeCallbacks(hideStripR); ui.postDelayed(hideStripR, 5000); }
        }
        return super.dispatchGenericMotionEvent(e);
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab t = tabs.remove(i);
        content.removeView(t.wv);
        if (t.incognito) t.wv.clearCache(true);
        t.wv.destroy();
        if (tabs.isEmpty()) { cur = -1; newTab(prefs.getString("home", "https://yandex.ru"), false); return; }
        switchTo(Math.min(i, tabs.size() - 1));
        saveTabsSoon();
        boolean anyIncog = false;
        for (Tab x : tabs) anyIncog |= x.incognito;
        if (t.incognito && !anyIncog) { CookieManager.getInstance().removeSessionCookies(null); }
    }

    void toggleDesktop() {
        Tab t = tab(); if (t == null) return;
        t.desktop = !t.desktop;
        WebSettings s = t.wv.getSettings();
        s.setUserAgentString(t.desktop ? DESKTOP_UA : null);
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true);
        t.wv.reload();
    }

    WebView makeWebView(Tab t) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        if (t.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, !prefs.getBoolean("block3p", true));
        t.uid = ++tabSeq;
        w.addJavascriptInterface(new VaultHook(t), "PrismaVault");
        w.addJavascriptInterface(new TrHook(t), "PrismaTr");
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl(); String sc = u.getScheme() == null ? "" : u.getScheme();
                if (sc.equals("http") || sc.equals("https") || sc.equals("about") || sc.equals("data") || sc.equals("blob")) return false;
                if (sc.equals("tel")) {
                    JSONObject a = new JSONObject();
                    try { a.put("phone", u.getSchemeSpecificPart()); } catch (Exception ignored) {}
                    openPanel("call", a.toString()); return true;
                }
                try {
                    Intent i = sc.equals("intent") ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, u);
                    i.addCategory(Intent.CATEGORY_BROWSABLE);
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                        String fb = i.getStringExtra("browser_fallback_url");
                        if (fb != null) v.loadUrl(fb);
                    } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame() && adblock.isBlocked(r.getUrl().getHost()))
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                return null;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                t.report = url != null && url.startsWith(REPORT_BASE);
                t.url = url;
                if (t == tab()) showUrl(url);
            }
            @Override public void onPageFinished(WebView v, String url) {
                t.url = url; t.title = v.getTitle() == null ? "" : v.getTitle();
                if (t == tab()) { showUrl(url); progress.setProgress(0); }
                if (t.report) { if (t == tab()) showUrl(url); return; }
                saveTabsSoon();
                if (!t.incognito && url.startsWith("http")) {
                    panelJs("App.onVisit(" + q(url) + "," + q(t.title) + ")");
                    prefs.edit().putString("lastUrl", url).apply();
                }
                if (t.pendingAgents != null) { String a = t.pendingAgents; t.pendingAgents = null; openPanel("agents", a); }
                if (url.startsWith("http")) { v.evaluateJavascript(pfJs + "\n" + hookJs, null); afterLoadTranslate(t, url); }
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { if (t == tab()) progress.setProgress(p >= 100 ? 0 : p); }
            @Override public void onReceivedTitle(WebView v, String title) { t.title = title; }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                String[] acc = p.getAcceptTypes();
                boolean img = acc == null || acc.length == 0;
                if (acc != null) for (String a : acc) if (a == null || a.isEmpty() || a.startsWith("image") || a.equals("*/*")) img = true;
                final boolean wantsImg = img;
                Intent content = p.createIntent();
                if (!wantsImg) {
                    try { startActivityForResult(content, 77); } catch (Exception e) { fileCb = null; return false; }
                    return true;
                }
                withPermission(android.Manifest.permission.CAMERA, () -> {
                    try { startActivityForResult(p.isCaptureEnabled() ? cameraIntent() : chooserWithCamera(content), 77); }
                    catch (Exception e) { if (fileCb != null) fileCb.onReceiveValue(null); fileCb = null; }
                }, () -> { try { startActivityForResult(content, 77); } catch (Exception e) { if (fileCb != null) fileCb.onReceiveValue(null); fileCb = null; } });
                return true;
            }
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> sitePermission(req, Vault.hostOf(t.url)));
            }
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                customView = view; customCb = cb;
                fullscreenHolder.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenHolder.setVisibility(View.VISIBLE);
            }
            @Override public void onHideCustomView() { exitFullscreen(); }
        });
        w.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                String name = URLUtil.guessFileName(url, cd, mime);
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) r.addRequestHeader("Cookie", ck);
                r.addRequestHeader("User-Agent", ua);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Загружается: " + name, Toast.LENGTH_SHORT).show();
                panelJs("App.onDownload(" + q(name) + "," + q(url) + "," + len + ")");
            } catch (Exception e) {
                Toast.makeText(this, "Не удалось начать загрузку", Toast.LENGTH_SHORT).show();
            }
        });
        return w;
    }

    void exitFullscreen() {
        if (customView == null) return;
        fullscreenHolder.removeView(customView);
        fullscreenHolder.setVisibility(View.GONE);
        if (customCb != null) customCb.onCustomViewHidden();
        customView = null; customCb = null;
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == 14) {
            Runnable[] r = pendingPermPair; pendingPermPair = null;
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            if (r != null) { if (ok) r[0].run(); else { toast("Без доступа к камере — только выбор из галереи"); if (r[1] != null) r[1].run(); } }
        }
        if (req == 15 && pendingWebPerm != null) {
            boolean ok = true; for (int x : res) ok &= x == PackageManager.PERMISSION_GRANTED;
            if (ok) pendingWebPerm.grant(pendingWebRes); else pendingWebPerm.deny();
            pendingWebPerm = null;
        }
        if (req == 8 && pendingMic != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingMic.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else { pendingMic.deny(); Toast.makeText(this, "Без доступа к микрофону голосовой агент не работает", Toast.LENGTH_LONG).show(); }
            pendingMic = null;
        }
    }

    // ---------- swipe back: from the right edge to the left (and from the left edge to the right) ----------
    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        if (barView != null && !panelOpen) {
            int[] bl = new int[2]; barView.getLocationOnScreen(bl);
            boolean inBar = e.getRawY() >= bl[1] && e.getRawY() <= bl[1] + barView.getHeight();
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) barTracking = inBar;
            if (barTracking && barTouch(e)) {
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    MotionEvent c = MotionEvent.obtain(e); c.setAction(MotionEvent.ACTION_CANCEL); super.dispatchTouchEvent(c); c.recycle();
                }
                return true;
            }
            if (stripOpen && e.getActionMasked() == MotionEvent.ACTION_DOWN && !inBar) {
                int[] sl = new int[2]; stripScroll.getLocationOnScreen(sl);
                if (e.getRawY() < sl[1]) { hideStrip(); }
            }
        }
        if (panelOpen || customView != null || content == null) return super.dispatchTouchEvent(e);
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            swX = e.getRawX(); swY = e.getRawY(); swiping = false; swEdge = 0;
            int[] loc = new int[2]; content.getLocationOnScreen(loc);
            if (swY >= loc[1] && swY <= loc[1] + content.getHeight()) {
                if (swX <= loc[0] + dp(26)) swEdge = 1;
                else if (swX >= loc[0] + content.getWidth() - dp(26)) swEdge = -1;
            }
        } else if (act == MotionEvent.ACTION_MOVE && swEdge != 0) {
            float dx = (e.getRawX() - swX) * swEdge, dy = Math.abs(e.getRawY() - swY);
            if (!swiping && dx > dp(14) && dx > dy * 1.6f) {
                swiping = true;
                MotionEvent c = MotionEvent.obtain(e); c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c); c.recycle();
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) swipeHint.getLayoutParams();
                lp.gravity = (swEdge == 1 ? Gravity.START : Gravity.END) | Gravity.CENTER_VERTICAL;
                swipeHint.setLayoutParams(lp);
            }
            if (swiping) {
                float p = Math.min(1f, dx / dp(110));
                swipeHint.setAlpha(p);
                swipeHint.setTranslationX(swEdge * (-dp(48) + p * dp(64)));
                swipeHint.setScaleX(0.7f + 0.3f * p); swipeHint.setScaleY(0.7f + 0.3f * p);
                return true;
            }
        } else if ((act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) && swiping) {
            float dx = (e.getRawX() - swX) * swEdge;
            swipeHint.animate().alpha(0f).setDuration(150).start();
            swiping = false; swEdge = 0;
            if (act == MotionEvent.ACTION_UP && dx > dp(110)) {
                haptic();
                Tab t = tab();
                if (t != null && t.wv.canGoBack()) t.wv.goBack();
                else Toast.makeText(this, "Это первая страница вкладки", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return super.dispatchTouchEvent(e);
    }

    // ---------- default browser ----------
    boolean isDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_BROWSER)) return rm.isRoleHeld(RoleManager.ROLE_BROWSER);
            }
            android.content.pm.ResolveInfo ri = getPackageManager().resolveActivity(
                    new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), PackageManager.MATCH_DEFAULT_ONLY);
            return ri != null && ri.activityInfo != null && getPackageName().equals(ri.activityInfo.packageName);
        } catch (Exception e) { return false; }
    }

    void requestDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_BROWSER) && !rm.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_BROWSER), 90);
                    return;
                }
            }
        } catch (Exception ignored) {}
        try { startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)); }
        catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
    }

    // ---------- camera ----------
    Runnable[] pendingPermPair;
    void withPermission(String perm, Runnable ok, Runnable denied) {
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) { ok.run(); return; }
        pendingPermPair = new Runnable[]{ok, denied};
        requestPermissions(new String[]{perm}, 14);
    }

    Intent cameraIntent() {
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "prisma_" + System.currentTimeMillis() + ".jpg");
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Prisma");
        photoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        cam.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return cam;
    }

    Intent chooserWithCamera(Intent content) {
        Intent ch = Intent.createChooser(content, "Фото");
        ch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent()});
        return ch;
    }

    void dropPhotoUri() {
        if (photoUri != null) { try { getContentResolver().delete(photoUri, null, null); } catch (Exception ignored) {} photoUri = null; }
    }

    /** reads an image, fixes EXIF rotation, scales to maxSide, returns JPEG base64 */
    String loadJpegB64(Uri u, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
            int sample = 1; while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options(); o2.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) return null;
            int rot = 0;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                android.media.ExifInterface ex = new android.media.ExifInterface(in);
                int or = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            } catch (Exception ignored) {}
            float sc = Math.min(1f, (float) maxSide / Math.max(b.getWidth(), b.getHeight()));
            Matrix m = new Matrix(); m.postScale(sc, sc); if (rot != 0) m.postRotate(rot);
            Bitmap out = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            out.compress(Bitmap.CompressFormat.JPEG, 85, bo);
            return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return null; }
    }

    /** a site asks for camera / microphone — ask Den like Chrome does */
    void sitePermission(PermissionRequest req, String host) {
        java.util.List<String> res = new java.util.ArrayList<>(), perms = new java.util.ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) { res.add(r); perms.add(android.Manifest.permission.CAMERA); }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) { res.add(r); perms.add(android.Manifest.permission.RECORD_AUDIO); }
        }
        if (res.isEmpty()) { req.deny(); return; }
        String what = perms.size() == 2 ? "камере и микрофону" : perms.contains(android.Manifest.permission.CAMERA) ? "камере" : "микрофону";
        String key = "site_" + host + "_" + what;
        Runnable grant = () -> {
            java.util.List<String> need = new java.util.ArrayList<>();
            for (String pm : perms) if (checkSelfPermission(pm) != PackageManager.PERMISSION_GRANTED) need.add(pm);
            String[] rr = res.toArray(new String[0]);
            if (need.isEmpty()) { req.grant(rr); return; }
            pendingWebPerm = req; pendingWebRes = rr;
            requestPermissions(need.toArray(new String[0]), 15);
        };
        if (prefs.getBoolean(key, false)) { grant.run(); return; }
        new AlertDialog.Builder(this)
                .setTitle(host)
                .setMessage("Сайт просит доступ к " + what + ".")
                .setPositiveButton("Разрешить", (d, w) -> { prefs.edit().putBoolean(key, true).apply(); grant.run(); })
                .setNegativeButton("Запретить", (d, w) -> req.deny())
                .setOnCancelListener(d -> req.deny())
                .show();
    }

    // ---------- page translation in place (like Yandex Browser) ----------
    static String langName(String l) {
        switch (l) { case "es": return "испанском"; case "en": return "английском"; case "fr": return "французском"; case "de": return "немецком";
            case "it": return "итальянском"; case "pt": return "португальском"; case "ru": return "русском"; case "uk": return "украинском"; default: return l; }
    }
    static String langShort(String l) {
        switch (l) { case "es": return "испанского"; case "en": return "английского"; case "fr": return "французского"; case "de": return "немецкого";
            case "it": return "итальянского"; case "pt": return "португальского"; case "ru": return "русского"; case "uk": return "украинского"; default: return l; }
    }
    java.util.Set<String> trAuto() { return new java.util.HashSet<>(java.util.Arrays.asList(prefs.getString("trAuto", "").split(","))); }

    void afterLoadTranslate(Tab t, String url) {
        if (t.report) return;
        String host = Vault.hostOf(url);
        t.translating = false; t.trLeft = 0;
        t.wv.evaluateJavascript(trJs + ";window.__trLang()", r -> {
            String lang = r == null ? "" : r.replace("\"", "").trim();
            String target = prefs.getString("trTarget", "ru");
            if (lang.isEmpty() || lang.equals("null") || lang.equals(target)) { if (t == tab()) showUrl(t.url); return; }
            // keep translating while browsing the same site, and always for "auto" languages
            if (host.equals(t.trHost) || trAuto().contains(lang)) { startTranslate(t); return; }
            if (!prefs.getBoolean("trOffer", true) || t != tab() || url.equals(t.trAsked) || prefs.getBoolean("trNever_" + lang, false)) return;
            t.trAsked = url;
            String tl = target.equals("ru") ? "русский" : "английский";
            showBanner("Страница на " + langName(lang) + " языке. Перевести на " + tl + "?",
                    new String[]{"Перевести", "Всегда с " + langShort(lang), "Нет"},
                    new Runnable[]{() -> startTranslate(t),
                            () -> { java.util.Set<String> a = trAuto(); a.add(lang); a.remove("");
                                prefs.edit().putString("trAuto", android.text.TextUtils.join(",", a)).apply();
                                panelJs("App.trAutoChanged&&App.trAutoChanged(" + q(prefs.getString("trAuto", "")) + ")");
                                startTranslate(t); },
                            null});
        });
    }

    void startTranslate(Tab t) {
        t.translating = true; t.trHost = Vault.hostOf(t.url);
        t.wv.evaluateJavascript(trJs + ";window.__trStart(" + q(prefs.getString("trTarget", "ru")) + ")", null);
        if (t == tab()) showUrl(t.url);
    }

    void stopTranslate(Tab t) {
        t.translating = false; t.trHost = null; t.trLeft = 0;
        t.wv.evaluateJavascript("window.__trStop&&window.__trStop()", null);
        if (t == tab()) showUrl(t.url);
    }

    class TrHook {
        final Tab t;
        TrHook(Tab t) { this.t = t; }
        /** a batch of page texts to translate — accepted only while Den has translation switched on for this tab */
        @JavascriptInterface public void request(String id, String json) {
            if (!t.translating || json == null || json.length() > 20000) return;
            String key = t.uid + ":" + id;
            synchronized (trReqs) { trReqs.put(key, t); }
            panelJs("App._trReq(" + q(key) + "," + q(json) + ")");
        }
        @JavascriptInterface public void progress(int left) {
            ui.post(() -> { t.trLeft = left; if (t == tab()) showUrl(t.url); });
        }
    }

    // ---------- saved logins ----------
    class VaultHook {
        final Tab t;
        VaultHook(Tab t) { this.t = t; }

        /** page reports a login form being submitted */
        @JavascriptInterface public void offer(String user, String pass) {
            ui.post(() -> {
                if (t.incognito || pass == null || pass.isEmpty() || !prefs.getBoolean("vaultOffer", true)) return;
                String host = Vault.hostOf(t.url);
                if (host.isEmpty() || vault.never(host)) return;
                String key = host + "|" + user + "|" + pass;
                if (key.equals(lastOffer) && System.currentTimeMillis() - lastOfferAt < 30000) return;
                lastOffer = key; lastOfferAt = System.currentTimeMillis();
                int st = vault.status(host, user == null ? "" : user, pass);
                if (st == 0) return;
                String who = (user == null || user.isEmpty()) ? "" : " (" + user + ")";
                showBanner((st == 2 ? "Обновить пароль для " : "Сохранить пароль для ") + host + who + "?",
                        new String[]{st == 2 ? "Обновить" : "Сохранить", "Никогда", "Нет"},
                        new Runnable[]{() -> { vault.save(host, user == null ? "" : user, pass, t.url); toast("Пароль сохранён — в зашифрованном хранилище телефона"); },
                                () -> vault.addNever(host), null});
            });
        }

        /** page reports a fillable form: number of profile fields and whether card fields are present */
        @JavascriptInterface public void forms(int nProfile, boolean card) {
            ui.post(() -> {
                if (t != tab() || t.incognito || t.url.equals(t.formsFor) || !prefs.getBoolean("pfOffer", true)) return;
                try {
                    JSONObject sum = new JSONObject(vault.profileSummary());
                    if (sum.length() == 0) return;
                    if (card && sum.has("ccNumber")) {
                        t.formsFor = t.url;
                        showBanner("Заполнить карту •••• " + sum.optString("ccLast4") + "? CVV введёшь сам.", new String[]{"Заполнить", "Нет"},
                                new Runnable[]{() -> fillProfile(t, true, null, null), null});
                    } else if (nProfile >= 2) {
                        t.formsFor = t.url;
                        showBanner("Заполнить форму моими данными?", new String[]{"Заполнить", "Нет"},
                                new Runnable[]{() -> fillProfile(t, false, null, null), null});
                    }
                } catch (Exception ignored) {}
            });
        }

        /** page reports whether it shows a login form */
        @JavascriptInterface public void page(boolean hasPw, boolean hasUser) {
            ui.post(() -> {
                String host = Vault.hostOf(t.url);
                java.util.List<JSONObject> list = vault.forHost(host);
                if (list.isEmpty()) return;
                if (t.pendingLogin && (hasPw || hasUser)) {
                    if (t.loginSteps++ > 3) { t.pendingLogin = false; return; }
                    JSONObject c = null;
                    if (t.loginId != null) for (JSONObject o : list) if (t.loginId.equals(o.optString("id"))) c = o;
                    if (c == null && list.size() == 1) c = list.get(0);
                    if (c != null) { fillLogin(t, c, true); return; }
                    t.pendingLogin = false; chooseLogin(t, list); return;
                }
                if (!hasPw || t != tab() || t.url.equals(t.bannerFor)) return;
                t.bannerFor = t.url;
                String u = list.size() == 1 ? list.get(0).optString("user") : list.size() + " аккаунта";
                showBanner("Войти на " + host + " как " + u + "?", new String[]{"Войти", "Не сейчас"},
                        new Runnable[]{() -> chooseLogin(t, list), null});
            });
        }
    }

    void chooseLogin(Tab t, java.util.List<JSONObject> list) {
        if (list.size() == 1) { fillLogin(t, list.get(0), true); return; }
        PopupMenu m = new PopupMenu(this, siteLabel);
        for (int i = 0; i < list.size(); i++) m.getMenu().add(0, i, i, list.get(i).optString("user"));
        m.setOnMenuItemClickListener(it -> { fillLogin(t, list.get(it.getItemId()), true); return true; });
        m.show();
    }

    void fillLogin(Tab t, JSONObject c, boolean submit) {
        authenticate("Вход на " + c.optString("host"), () -> {
            boolean sub = submit && prefs.getBoolean("vaultSubmit", true);
            t.wv.evaluateJavascript(fillJs + ";__pvFill(" + q(c.optString("user")) + "," + q(c.optString("pass")) + "," + sub + ")", r -> {
                if (r != null && r.contains("user-step")) { t.pendingLogin = true; t.loginId = c.optString("id"); }
                else { t.pendingLogin = false; t.loginId = null; }
                if (r != null && r.contains("none")) toast("Не нашёл поля входа на этой странице");
            });
        });
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    interface StrCb { void done(String s); }
    /** fills the open page with Den's data; values stay on the phone (only field labels may go to the AI for matching) */
    void fillProfile(Tab t, boolean card, String mapJson, StrCb cb) {
        Runnable go = () -> {
            String js = pfJs + ";__pfFill(" + vault.getProfile() + ",{card:" + card + ",map:" + (mapJson == null || mapJson.isEmpty() ? "{}" : mapJson) + "})";
            t.wv.evaluateJavascript(js, r -> {
                String res = "{}";
                try { res = new JSONArray("[" + r + "]").getString(0); } catch (Exception ignored) {}
                if (cb != null) { cb.done(res); return; }
                try {
                    JSONObject o = new JSONObject(res);
                    int n = o.optJSONArray("filled") == null ? 0 : o.optJSONArray("filled").length();
                    toast(n == 0 ? "Подходящих полей не нашёл" : "Заполнено полей: " + n + (card ? ". CVV введи сам и проверь перед оплатой" : ". Проверь и отправь сам"));
                } catch (Exception ignored) {}
            });
        };
        if (card) authenticateFresh("Заполнить данные карты", go);
        else authenticate("Заполнить форму личными данными", go);
    }

    void authenticateFresh(String why, Runnable ok) { unlockedUntil = 0; authenticate(why, ok); }

    /** fingerprint / face / phone PIN; one unlock is valid for 5 minutes */
    void authenticate(String why, Runnable ok) {
        if (System.currentTimeMillis() < unlockedUntil) { ok.run(); return; }
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km == null || !km.isDeviceSecure()) {
            toast("На телефоне нет блокировки экрана — пароли открываются без отпечатка");
            ok.run(); return;
        }
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                android.hardware.biometrics.BiometricPrompt.Builder b = new android.hardware.biometrics.BiometricPrompt.Builder(this)
                        .setTitle("Призма — пароли").setSubtitle(why);
                if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK
                        | android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL);
                else if (Build.VERSION.SDK_INT == 29) b.setDeviceCredentialAllowed(true);
                else b.setNegativeButton("Отмена", getMainExecutor(), (d, w) -> {});
                b.build().authenticate(new CancellationSignal(), getMainExecutor(), new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult r) {
                        unlockedUntil = System.currentTimeMillis() + 5 * 60_000; ok.run();
                    }
                    @Override public void onAuthenticationError(int code, CharSequence msg) {
                        if (code != android.hardware.biometrics.BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                                && code != android.hardware.biometrics.BiometricPrompt.BIOMETRIC_ERROR_CANCELED) toast(String.valueOf(msg));
                    }
                });
                return;
            } catch (Exception ignored) {}
        }
        Intent i = km.createConfirmDeviceCredentialIntent("Призма — пароли", why);
        if (i == null) { ok.run(); return; }
        pendingAuth = ok;
        startActivityForResult(i, 91);
    }

    void showBanner(String text, String[] labels, Runnable[] actions) {
        banner.removeAllViews();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(dark ? Color.parseColor("#1C1C1E") : Color.WHITE); bg.setCornerRadius(dp(16));
        banner.setBackground(bg);
        TextView tx = new TextView(this);
        tx.setText(text); tx.setTextSize(15); tx.setTextColor(cText);
        banner.addView(tx, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.END);
        for (int i = 0; i < labels.length; i++) {
            final Runnable r = actions[i];
            TextView b = new TextView(this);
            b.setText(labels[i]); b.setTextSize(15); b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setTextColor(i == 0 ? cAccent : cMute);
            b.setPadding(dp(12), dp(10), dp(12), dp(8));
            click(b, v -> { hideBanner(); if (r != null) r.run(); });
            row.addView(b, 0);
        }
        banner.addView(row, new LinearLayout.LayoutParams(-1, -2));
        banner.setVisibility(View.VISIBLE);
        banner.setAlpha(0f); banner.setTranslationY(dp(30));
        banner.animate().alpha(1f).translationY(0).setDuration(220).start();
        banner.removeCallbacks(hideBannerR);
        banner.postDelayed(hideBannerR, 15000);
    }
    final Runnable hideBannerR = this::hideBanner;
    void hideBanner() { if (banner.getVisibility() == View.VISIBLE) banner.animate().alpha(0f).setDuration(150).withEndAction(() -> banner.setVisibility(View.GONE)).start(); }

    @Override protected void onDestroy() { if (tts != null) tts.shutdown(); super.onDestroy(); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 91) {
            Runnable r = pendingAuth; pendingAuth = null;
            if (res == RESULT_OK && r != null) { unlockedUntil = System.currentTimeMillis() + 5 * 60_000; r.run(); }
            return;
        }
        if (req == 90) {
            boolean ok = isDefaultBrowser();
            Toast.makeText(this, ok ? "Призма — браузер по умолчанию" : "Можно выбрать позже: Настройки → Приложения по умолчанию → Браузер", Toast.LENGTH_LONG).show();
            if (!ok) { try { startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)); } catch (Exception ignored) {} }
            panelJs("App.refresh && App.refresh()");
            return;
        }
        if (req == 77 && fileCb != null) {
            Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
            if (res == RESULT_OK && (r == null || r.length == 0) && photoUri != null) r = new Uri[]{photoUri};
            else if (res != RESULT_OK) dropPhotoUri();
            fileCb.onReceiveValue(r);
            fileCb = null;
        }
        if (req == 78) {
            String id = pendingPhotoId; pendingPhotoId = null;
            Uri u = (res == RESULT_OK) ? ((data != null && data.getData() != null) ? data.getData() : photoUri) : null;
            if (u == null) { dropPhotoUri(); panelJs("App._photo(" + q(id) + ",null)"); return; }
            final Uri fu = u;
            new Thread(() -> {
                String b64 = loadJpegB64(fu, 1600);
                panelJs("App._photo(" + q(id) + "," + (b64 == null ? "null" : q(b64)) + ")");
            }).start();
        }
    }

    // ---------- panel ----------
    void setupPanel() {
        WebSettings s = panel.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        panel.addJavascriptInterface(new Bridge(), "Native");
        panel.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        panel.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                panelReady = true;
                for (String js : panelQueue) panel.evaluateJavascript(js, null);
                panelQueue.clear();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http")) { closePanel(); newTab(u, false); }
                return true;
            }
        });
        panel.getSettings().setMediaPlaybackRequiresUserGesture(false);
        panel.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean audio = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                    if (!audio) { req.deny(); return; }
                    if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingMic = req;
                        requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 8);
                    }
                });
            }
        });
        panel.loadUrl("file:///android_asset/panel.html");
    }

    void panelJs(String js) {
        ui.post(() -> { if (panelReady) panel.evaluateJavascript(js, null); else panelQueue.add(js); });
    }

    void openPanel(String route, String arg) {
        ui.post(() -> {
            hideKeyboard();
            if (inputRow != null) inputRow.setVisibility(View.GONE);
            boolean wasHidden = panel.getVisibility() != View.VISIBLE;
            panel.setVisibility(View.VISIBLE);
            if (wasHidden && route.equals("agent")) {
                panel.setTranslationY(stack.getHeight() > 0 ? stack.getHeight() : dp(600));
                panel.animate().translationY(0).setDuration(320).setInterpolator(new android.view.animation.DecelerateInterpolator(2f)).start();
            } else panel.setTranslationY(0);
            panelOpen = true;
            panelJs("App.open(" + q(route) + "," + q(arg) + ")");
        });
    }

    void closePanel() {
        ui.post(() -> { panel.setVisibility(View.GONE); panelOpen = false; });
    }

    @Override public void onBackPressed() {
        if (customView != null) { exitFullscreen(); return; }
        if (inputRow != null && inputRow.getVisibility() == View.VISIBLE) { closeInput(); return; }
        if (panelOpen) { panelJs("App.back()"); return; }
        Tab t = tab();
        if (t != null && t.wv.canGoBack()) { t.wv.goBack(); return; }
        super.onBackPressed();
    }

    // ---------- intents ----------
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); handleIntent(i); }

    boolean handleIntent(Intent i) {
        if (i == null) return false;
        String openRoute = i.getStringExtra("openRoute");
        if (openRoute != null) {
            if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false);
            i.removeExtra("openRoute");
            if (!openRoute.isEmpty()) openPanel(openRoute, "");
            return true;
        }
        String act = i.getAction();
        try {
            if (Intent.ACTION_VIEW.equals(act) && i.getData() != null) {
                Uri u = i.getData();
                if ("prisma".equals(u.getScheme())) {
                    String host = u.getHost() == null ? "" : u.getHost();
                    String url = u.getQueryParameter("url");
                    JSONObject a = new JSONObject();
                    for (String k : u.getQueryParameterNames()) a.put(k, u.getQueryParameter(k));
                    if (host.equals("open")) { if (url != null) newTab(url, false); else if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false); }
                    else if (host.equals("analyze") || host.equals("ask")) {
                        a.put("auto", !"0".equals(u.getQueryParameter("auto")));
                        if (url != null) { Tab t = newTab(url, false); t.pendingAgents = a.toString(); }
                        else { if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false); openPanel("agents", a.toString()); }
                    } else if (host.equals("links")) {
                        if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false);
                        openPanel("links", "");
                    } else return false;
                    return true;
                }
                newTab(u.toString(), false);
                return true;
            }
            if (Intent.ACTION_WEB_SEARCH.equals(act)) {
                String qy = i.getStringExtra("query");
                if (qy == null || qy.isEmpty()) return false;
                if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false);
                JSONObject a = new JSONObject(); a.put("q", qy); a.put("mode", "search");
                openPanel("agent", a.toString());
                return true;
            }
            if (Intent.ACTION_SEND.equals(act)) {
                String text = i.getStringExtra(Intent.EXTRA_TEXT);
                if (text == null) return false;
                String subj = i.getStringExtra(Intent.EXTRA_SUBJECT);
                Matcher m = Patterns.WEB_URL.matcher(text);
                String url = null;
                while (m.find()) { String g = m.group(); if (g.startsWith("http")) { url = g; break; } }
                JSONObject a = new JSONObject();
                a.put("q", ""); a.put("shared", (subj != null ? subj + "\n" : "") + text); a.put("auto", false);
                if (url != null) { Tab t = newTab(url, false); t.pendingAgents = a.toString(); }
                else { if (tabs.isEmpty()) newTab(prefs.getString("home", "https://yandex.ru"), false); openPanel("agents", a.toString()); }
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    @Override protected void onPause() { super.onPause(); inFront = false; Tab t = tab(); if (t != null) t.wv.onPause(); CookieManager.getInstance().flush(); }
    @Override protected void onResume() { super.onResume(); inFront = true; Tab t = tab(); if (t != null) t.wv.onResume(); }

    static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toString("UTF-8");
    }

    // ---------- JS bridge for panel ----------
    class Bridge {
        @JavascriptInterface public void http(String id, String method, String url, String headersJson, String body, int timeoutSec) {
            new Thread(() -> {
                int code = 0; String resp;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(Math.max(30, timeoutSec) * 1000);
                    if (headersJson != null && !headersJson.isEmpty()) {
                        JSONObject h = new JSONObject(headersJson);
                        for (Iterator<String> it = h.keys(); it.hasNext(); ) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }
                    }
                    if (body != null && !body.isEmpty() && !method.equals("GET")) {
                        c.setDoOutput(true);
                        try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                    }
                    code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    resp = in == null ? "" : readAll(in);
                } catch (Exception e) { resp = "NETWORK: " + e.getClass().getSimpleName() + ": " + e.getMessage(); }
                panelJs("App._httpDone(" + q(id) + "," + code + "," + q(resp) + ")");
            }).start();
        }

        @JavascriptInterface public void pageText(String id, int index) {
            ui.post(() -> {
                int i = index < 0 ? cur : index;
                if (i < 0 || i >= tabs.size()) { panelJs("App._pageText(" + q(id) + ",null)"); return; }
                WebView w = tabs.get(i).wv;
                w.onResume();
                w.evaluateJavascript(extractJs, v -> {
                    if (i != cur) w.onPause();
                    panelJs("App._pageText(" + q(id) + "," + (v == null ? "null" : v) + ")");
                });
            });
        }

        @JavascriptInterface public String tabs() {
            JSONArray a = new JSONArray();
            try {
                for (int i = 0; i < tabs.size(); i++) {
                    Tab t = tabs.get(i);
                    JSONObject o = new JSONObject();
                    o.put("i", i); o.put("url", t.url); o.put("title", t.title); o.put("incognito", t.incognito); o.put("current", i == cur);
                    a.put(o);
                }
            } catch (Exception ignored) {}
            return a.toString();
        }

        @JavascriptInterface public String current() {
            JSONObject o = new JSONObject();
            try { Tab t = tab(); if (t != null) { o.put("url", t.url); o.put("title", t.title); o.put("incognito", t.incognito); o.put("i", cur); } } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface public void switchTab(int i) { ui.post(() -> { switchTo(i); closePanel(); }); }
        @JavascriptInterface public void closeTab(int i) { ui.post(() -> { MainActivity.this.closeTab(i); panelJs("App.refresh()"); }); }
        @JavascriptInterface public void newTab(String url, boolean incognito) { ui.post(() -> { MainActivity.this.newTab(url == null || url.isEmpty() ? prefs.getString("home", "https://yandex.ru") : url, incognito); closePanel(); }); }
        @JavascriptInterface public void open(String url) { ui.post(() -> { Tab t = tab(); if (t == null) MainActivity.this.newTab(url, false); else t.wv.loadUrl(url); closePanel(); }); }
        @JavascriptInterface public void closePanel() { MainActivity.this.closePanel(); }
        @JavascriptInterface public void toast(String m) { ui.post(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show()); }
        @JavascriptInterface public void haptic() { ui.post(MainActivity.this::haptic); }

        @JavascriptInterface public void copy(String text) {
            ui.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Призма", text));
                Toast.makeText(MainActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
            });
        }

        /** Share text; pkg empty = system chooser. Returns false if pkg not installed. */
        @JavascriptInterface public boolean share(String text, String subject, String pkg) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                if (subject != null && !subject.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.putExtra("prisma.source", "prisma");
                if (pkg != null && !pkg.isEmpty()) {
                    i.setPackage(pkg);
                    if (i.resolveActivity(getPackageManager()) == null) return false;
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } else startActivity(Intent.createChooser(i, "Отправить"));
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public boolean launch(String pkg) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return false;
                startActivity(i); return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public boolean installed(String pkg) {
            try { return getPackageManager().getLaunchIntentForPackage(pkg) != null; } catch (Exception e) { return false; }
        }

        @JavascriptInterface public boolean openUri(String uri) {
            try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface public void dial(String phone) {
            ui.post(() -> { try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone)))); } catch (Exception ignored) {} });
        }

        @JavascriptInterface public void config(String json) {
            try {
                JSONObject o = new JSONObject(json);
                SharedPreferences.Editor e = prefs.edit();
                if (o.has("home")) e.putString("home", o.getString("home"));
                if (o.has("search")) e.putString("search", o.getString("search"));
                if (o.has("searchMode")) e.putString("searchMode", o.getString("searchMode"));
                if (o.has("haptic")) e.putBoolean("haptic", o.getBoolean("haptic"));
                if (o.has("vaultOffer")) e.putBoolean("vaultOffer", o.getBoolean("vaultOffer"));
                if (o.has("addrEnglish")) e.putBoolean("addrEnglish", o.getBoolean("addrEnglish"));
                if (o.has("pfOffer")) e.putBoolean("pfOffer", o.getBoolean("pfOffer"));
                if (o.has("trTarget")) e.putString("trTarget", o.getString("trTarget"));
                if (o.has("trOffer")) e.putBoolean("trOffer", o.getBoolean("trOffer"));
                if (o.has("trAuto")) e.putString("trAuto", o.getString("trAuto"));
                if (o.has("vaultSubmit")) e.putBoolean("vaultSubmit", o.getBoolean("vaultSubmit"));
                if (o.has("block3p")) e.putBoolean("block3p", o.getBoolean("block3p"));
                if (o.has("adblock")) { e.putBoolean("adblock", o.getBoolean("adblock")); adblock.enabled = o.getBoolean("adblock"); }
                e.apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public String adblockInfo() {
            return "{\"enabled\":" + adblock.enabled + ",\"hosts\":" + adblock.size() + ",\"blocked\":" + adblock.blockedCount + "}";
        }

        @JavascriptInterface public void adblockUpdate(String id, String url) {
            new Thread(() -> { int n = adblock.download(url); panelJs("App._adblockDone(" + q(id) + "," + n + ")"); }).start();
        }

        @JavascriptInterface public void clearData(String what) {
            ui.post(() -> {
                if (what.contains("cookies")) { CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); }
                if (what.contains("cache")) for (Tab t : tabs) t.wv.clearCache(true);
                if (what.contains("storage")) WebStorage.getInstance().deleteAllData();
                Toast.makeText(MainActivity.this, "Очищено", Toast.LENGTH_SHORT).show();
            });
        }

        /** Saves a text file into Downloads/Prisma. */
        @JavascriptInterface public boolean saveFile(String name, String text, String mime) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Prisma");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (u == null) return false;
                    try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
                    ui.post(() -> Toast.makeText(MainActivity.this, "Сохранено в Загрузки/Prisma", Toast.LENGTH_SHORT).show());
                    return true;
                }
            } catch (Exception ignored) {}
            return false;
        }

        @JavascriptInterface public void setTheme(String mode) {
            ui.post(() -> {
                boolean d = "dark".equals(mode);
                prefs.edit().putString("theme", mode).apply();
                if (d == dark) return;
                dark = d; pickColors(); applyColors();
            });
        }

        /** Speech-to-text: multipart upload of base64 audio to an OpenAI-compatible /audio/transcriptions endpoint. */
        @JavascriptInterface public void transcribe(String id, String url, String key, String model, String lang, String prompt, String b64, String mime) {
            new Thread(() -> {
                int code = 0; String resp;
                try {
                    byte[] audio = Base64.decode(b64, Base64.DEFAULT);
                    String ext = mime != null && mime.contains("mp4") ? "m4a" : mime != null && mime.contains("ogg") ? "ogg" : "webm";
                    String bd = "----prisma" + System.currentTimeMillis();
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true);
                    c.setConnectTimeout(20000); c.setReadTimeout(90000);
                    c.setRequestProperty("Authorization", "Bearer " + key);
                    c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + bd);
                    try (OutputStream o = c.getOutputStream()) {
                        String head = "--" + bd + "\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\n" + model + "\r\n";
                        if (lang != null && !lang.isEmpty()) head += "--" + bd + "\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\n" + lang + "\r\n";
                        if (prompt != null && !prompt.isEmpty()) head += "--" + bd + "\r\nContent-Disposition: form-data; name=\"prompt\"\r\n\r\n" + prompt + "\r\n";
                        head += "--" + bd + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voice." + ext + "\"\r\nContent-Type: " + mime + "\r\n\r\n";
                        o.write(head.getBytes(StandardCharsets.UTF_8));
                        o.write(audio);
                        o.write(("\r\n--" + bd + "--\r\n").getBytes(StandardCharsets.UTF_8));
                    }
                    code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    resp = in == null ? "" : readAll(in);
                } catch (Exception e) { resp = "NETWORK: " + e.getMessage(); }
                panelJs("App._httpDone(" + q(id) + "," + code + "," + q(resp) + ")");
            }).start();
        }

        @JavascriptInterface public void speak(String text, String lang) {
            ui.post(() -> {
                if (!ttsReady || tts == null) { Toast.makeText(MainActivity.this, "Синтез речи недоступен на устройстве", Toast.LENGTH_SHORT).show(); return; }
                tts.setLanguage(lang == null || lang.isEmpty() ? new Locale("ru", "RU") : Locale.forLanguageTag(lang));
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "prisma");
            });
        }

        @JavascriptInterface public void stopSpeak() { ui.post(() -> { if (tts != null) tts.stop(); }); }

        @JavascriptInterface public void nav(String op) {
            ui.post(() -> {
                Tab t = tab(); if (t == null) return;
                if (op.equals("back") && t.wv.canGoBack()) t.wv.goBack();
                else if (op.equals("forward") && t.wv.canGoForward()) t.wv.goForward();
                else if (op.equals("reload")) t.wv.reload();
                else if (op.equals("close")) MainActivity.this.closeTab(cur);
                MainActivity.this.closePanel();
            });
        }

        @JavascriptInterface public void trReply(String key, String arrJson) {
            Tab t; synchronized (trReqs) { t = trReqs.remove(key); }
            if (t == null) return;
            String id = key.substring(key.indexOf(':') + 1);
            String safe;
            try { safe = new JSONArray(arrJson).toString(); } catch (Exception e) { safe = "null"; }
            final String js = "window.__trApply&&window.__trApply(" + q(id) + "," + safe + ")";
            ui.post(() -> t.wv.evaluateJavascript(js, null));
        }
        @JavascriptInterface public boolean trToggle(int tabIndex) {
            final int i = tabIndex < 0 ? cur : tabIndex;
            if (i < 0 || i >= tabs.size()) return false;
            Tab t = tabs.get(i); boolean on = !t.translating;
            ui.post(() -> { if (on) startTranslate(t); else stopTranslate(t); MainActivity.this.closePanel(); });
            return on;
        }
        @JavascriptInterface public String vaultList() { return vault.listPublic(); }
        @JavascriptInterface public String profileSummary() { return vault.profileSummary(); }
        @JavascriptInterface public void profileGet(String reqId) {
            ui.post(() -> authenticate("Мои данные для форм", () -> panelJs("App._pfData(" + q(reqId) + "," + vault.getProfile() + ")")));
        }
        @JavascriptInterface public void profileSave(String json) { vault.setProfile(json); }
        @JavascriptInterface public void profileFill(String reqId, boolean card, String mapJson, int tabIndex) {
            ui.post(() -> {
                int i = tabIndex < 0 ? cur : tabIndex;
                if (i < 0 || i >= tabs.size()) { panelJs("App._pfResult(" + q(reqId) + ",null)"); return; }
                fillProfile(tabs.get(i), card, mapJson, res -> panelJs("App._pfResult(" + q(reqId) + "," + q(res) + ")"));
            });
        }
        @JavascriptInterface public void profileScan(String reqId, int tabIndex) {
            ui.post(() -> {
                int i = tabIndex < 0 ? cur : tabIndex;
                if (i < 0 || i >= tabs.size()) { panelJs("App._pfResult(" + q(reqId) + ",null)"); return; }
                tabs.get(i).wv.evaluateJavascript(pfJs + ";__pfFill({},{fill:false})", r -> {
                    String res = "{}"; try { res = new JSONArray("[" + r + "]").getString(0); } catch (Exception ignored) {}
                    panelJs("App._pfResult(" + q(reqId) + "," + q(res) + ")");
                });
            });
        }
        @JavascriptInterface public void vaultSave(String host, String user, String pass, String url) {
            String h = host.contains("://") ? Vault.hostOf(host) : host.toLowerCase().replaceFirst("^www\\.", "").replaceAll("/.*$", "");
            vault.save(h, user, pass, url == null || url.isEmpty() ? "https://" + h : url);
        }
        @JavascriptInterface public void vaultUpdate(String id, String host, String user, String pass) { vault.update(id, host, user, pass); }
        @JavascriptInterface public void vaultDelete(String id) { vault.delete(id); }
        @JavascriptInterface public void vaultCopy(String id) {
            ui.post(() -> { JSONObject o = vault.get(id); if (o == null) return;
                authenticate("Копировать пароль " + o.optString("host"), () -> {
                    ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("password", o.optString("pass")));
                    toast("Пароль скопирован");
                }); });
        }
        @JavascriptInterface public void vaultReveal(String reqId, String id) {
            ui.post(() -> { JSONObject o = vault.get(id); if (o == null) return;
                authenticate("Показать пароль " + o.optString("host"), () -> panelJs("App._vaultReveal(" + q(reqId) + "," + q(o.optString("pass")) + ")")); });
        }
        /** open a site and sign in with the saved login (used by the agent) */
        @JavascriptInterface public void loginTo(String url, String id) {
            ui.post(() -> {
                Tab t = tab();
                if (t == null) t = MainActivity.this.newTab("about:blank", false);
                t.pendingLogin = true; t.loginSteps = 0; t.loginId = (id == null || id.isEmpty()) ? null : id;
                t.wv.loadUrl(url);
                MainActivity.this.closePanel();
            });
        }

        @JavascriptInterface public void showKeyboard() {
            ui.postDelayed(() -> {
                panel.requestFocus();
                InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(panel, InputMethodManager.SHOW_IMPLICIT);
            }, 60);
        }

        /** foreground service: keeps agents running while the app is in the background */
        @JavascriptInterface public void bgStart(String text) {
            ui.post(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            && !prefs.getBoolean("askedNotif", false)) {
                        prefs.edit().putBoolean("askedNotif", true).apply();
                        requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 12);
                    }
                    Intent s = new Intent(MainActivity.this, AgentService.class).putExtra("text", text);
                    startForegroundService(s);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void bgStop(boolean last, String doneText, String route) {
            ui.post(() -> {
                try {
                    if (last) stopService(new Intent(MainActivity.this, AgentService.class));
                    if (!inFront && doneText != null && !doneText.isEmpty()) {
                        AgentService.channels(MainActivity.this);
                        android.app.Notification n = new android.app.Notification.Builder(MainActivity.this, AgentService.CH_DONE)
                                .setSmallIcon(R.drawable.ic_prism).setContentTitle("Призма").setContentText(doneText)
                                .setAutoCancel(true).setContentIntent(AgentService.open(MainActivity.this, route, 2)).build();
                        ((android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify((int) (System.currentTimeMillis() % 100000), n);
                    }
                } catch (Exception ignored) {}
            });
        }

        /** shows an agents' report as a page in a new browser tab */
        @JavascriptInterface public void openHtml(String title, String html) {
            ui.post(() -> {
                Tab t = MainActivity.this.newTab("", false);
                t.report = true; t.title = title; t.url = REPORT_BASE;
                t.wv.loadDataWithBaseURL(REPORT_BASE + System.currentTimeMillis(), html, "text/html", "utf-8", null);
                showUrl(t.url);
                MainActivity.this.closePanel();
            });
        }

        /** agent photo: mode "camera" or "pick" (gallery/files with camera option) */
        @JavascriptInterface public void takePhoto(String id, String mode) {
            ui.post(() -> {
                pendingPhotoId = id;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
                Runnable cam = () -> { try { startActivityForResult("pick".equals(mode) ? chooserWithCamera(pick) : cameraIntent(), 78); }
                    catch (Exception e) { toast("Камера недоступна"); panelJs("App._photo(" + q(id) + ",null)"); } };
                withPermission(android.Manifest.permission.CAMERA, cam, () -> {
                    try { startActivityForResult(pick, 78); } catch (Exception e) { panelJs("App._photo(" + q(id) + ",null)"); }
                });
            });
        }

        @JavascriptInterface public boolean isDefault() { return isDefaultBrowser(); }
        @JavascriptInterface public void makeDefault() { ui.post(MainActivity.this::requestDefaultBrowser); }

        @JavascriptInterface public void setAddress(String text) { ui.post(() -> showUrl(text)); }
    }
}
