package com.den.prisma;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Host-based blocker: built-in seed + downloadable hosts list (cached in app files). */
public class AdBlock {
    private static final String[] SEED = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "pagead2.googlesyndication.com",
        "connect.facebook.net", "an.facebook.com", "scorecardresearch.com", "taboola.com", "outbrain.com",
        "criteo.com", "criteo.net", "adnxs.com", "amazon-adsystem.com", "pubmatic.com", "rubiconproject.com",
        "openx.net", "adform.net", "quantserve.com", "hotjar.com", "moatads.com", "smartadserver.com",
        "teads.tv", "yadro.ru", "an.yandex.ru", "mc.yandex.ru", "ads.adfox.ru", "adfox.ru", "top-fwz1.mail.ru",
        "ad.mail.ru", "ads.yahoo.com", "advertising.com", "media.net", "zedo.com", "popads.net", "propellerads.com",
        "mgid.com", "adsrvr.org", "casalemedia.com", "3lift.com", "bidswitch.net", "sharethrough.com",
        "yieldmo.com", "adcolony.com", "applovin.com", "unityads.unity3d.com", "inmobi.com", "onesignal.com"
    };

    private final Context ctx;
    private volatile Set<String> hosts = new HashSet<>();
    public volatile boolean enabled = true;
    public volatile int blockedCount = 0;

    public AdBlock(Context ctx) {
        this.ctx = ctx;
        Set<String> s = new HashSet<>();
        Collections.addAll(s, SEED);
        hosts = s;
    }

    private File cache() { return new File(ctx.getFilesDir(), "hosts.txt"); }

    public void loadAsync() {
        new Thread(() -> {
            File f = cache();
            if (!f.exists()) return;
            try (FileInputStream in = new FileInputStream(f)) { hosts = parse(new BufferedReader(new InputStreamReader(in))); }
            catch (Exception ignored) {}
        }).start();
    }

    private Set<String> parse(BufferedReader r) throws Exception {
        Set<String> s = new HashSet<>(200000);
        Collections.addAll(s, SEED);
        String line;
        while ((line = r.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!")) continue;
            int hash = line.indexOf('#');
            if (hash > 0) line = line.substring(0, hash).trim();
            String host;
            if (line.startsWith("||")) { // adblock-style ||domain^
                host = line.substring(2);
                int c = host.indexOf('^'); if (c > 0) host = host.substring(0, c);
                if (host.contains("/") || host.contains("*")) continue;
            } else {
                String[] p = line.split("\\s+");
                host = p.length >= 2 ? p[1] : p[0];
            }
            host = host.toLowerCase();
            if (host.equals("localhost") || host.equals("0.0.0.0") || host.contains("local")) continue;
            if (host.indexOf('.') > 0) s.add(host);
        }
        return s;
    }

    /** Downloads a hosts list. Returns number of hosts or -1 on error. */
    public int download(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(20000); c.setReadTimeout(60000);
            File tmp = new File(ctx.getFilesDir(), "hosts.tmp");
            try (java.io.InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                byte[] b = new byte[65536]; int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
            }
            Set<String> s;
            try (FileInputStream in = new FileInputStream(tmp)) { s = parse(new BufferedReader(new InputStreamReader(in))); }
            if (s.size() < 100) return -1;
            tmp.renameTo(cache());
            hosts = s;
            return s.size();
        } catch (Exception e) { return -1; }
    }

    public int size() { return hosts.size(); }

    public boolean isBlocked(String host) {
        if (!enabled || host == null) return false;
        host = host.toLowerCase();
        Set<String> h = hosts;
        while (true) {
            if (h.contains(host)) { blockedCount++; return true; }
            int dot = host.indexOf('.');
            if (dot < 0 || host.indexOf('.', dot + 1) < 0) return false;
            host = host.substring(dot + 1);
        }
    }
}
