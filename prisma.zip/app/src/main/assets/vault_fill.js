window.__pvFill=function(u,p,submit){try{
 function vis(e){return e&&!e.disabled&&!e.readOnly&&e.offsetParent!==null;}
 function set(el,v){el.focus();var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(el,v);
  el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));el.blur&&el.blur();}
 var q='input[type=email],input[autocomplete=username],input[autocomplete=email],input[name*=user i],input[name*=login i],input[name*=email i],input[id*=user i],input[id*=login i],input[id*=email i]';
 var pw=[].slice.call(document.querySelectorAll('input[type=password]')).filter(vis)[0]||null,user=null;
 if(pw){var form=pw.form||document;[].slice.call(form.querySelectorAll('input')).filter(function(e){return vis(e)&&/^(text|email|tel)$/i.test(e.type||'text');})
   .forEach(function(e){if(e.compareDocumentPosition(pw)&4)user=e;});}
 if(!user)user=[].slice.call(document.querySelectorAll(q)).filter(vis)[0]||null;
 if(user&&u&&user.value!==u)set(user,u);
 if(pw)set(pw,p);
 function press(scope){var b=[].slice.call((scope||document).querySelectorAll('button[type=submit],input[type=submit],button:not([type])')).filter(vis)[0];if(b){b.click();return true;}return false;}
 if(submit){setTimeout(function(){var f=(pw||user)&&(pw||user).form;if(!press(f)){if(f){if(f.requestSubmit)f.requestSubmit();else f.submit();}else press(document);}},350);}
 return pw?'ok':(user?'user-step':'none');
}catch(e){return 'err';}};
