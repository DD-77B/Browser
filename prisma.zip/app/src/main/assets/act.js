(function(){
if(window.__act)return;window.__act=1;
var FINAL=/(realizar (el )?pedido|comprar (ahora|ya)|pagar( ahora| y finalizar)?$|^pagar|confirmar (y pagar|pedido|compra)|autorizar (el )?pago|place (your )?order|buy now|pay now|complete (order|purchase)|submit order|оплатить|купить сейчас|подтвердить (заказ|оплату)|kaufen|jetzt bezahlen)/i;
function vis(e){var r=e.getBoundingClientRect();if(r.width<2||r.height<2)return false;var s=getComputedStyle(e);return s.visibility!=='hidden'&&s.display!=='none'&&s.opacity!=='0';}
function txt(e){var t=((e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||e.getAttribute('alt')||e.placeholder||'')+'').replace(/\s+/g,' ').trim();
  if(!t){var im=e.tagName==='IMG'?e:e.querySelector&&e.querySelector('img');if(im)t='картинка: '+(im.alt||im.title||'').trim();}
  return t.slice(0,90);}
function label(e){
  var t=e.getAttribute('aria-label')||'';
  if(e.id){var l=document.querySelector('label[for="'+CSS.escape(e.id)+'"]');if(l)t=t||l.innerText;}
  var p=e.closest('label');if(p)t=t||p.innerText;
  return (t||e.placeholder||e.name||'').replace(/\s+/g,' ').trim().slice(0,70);
}
window.__actSnap=function(){
  var els=[].slice.call(document.querySelectorAll('a[href],button,input,select,textarea,[role=button],[role=link],[role=tab],[role=option],[role=radio],[role=checkbox],[onclick],summary,label[for]'));
  var vh=innerHeight,out=[],n=0;
  [].slice.call(document.querySelectorAll('[data-act]')).forEach(function(e){e.removeAttribute('data-act');});
  // elements that only look clickable (cursor:pointer, tabindex) — typical for AliExpress, Zara and other SPA stores
  var seen=new Set(els),extra=[],cand=document.querySelectorAll('div,span,li,img,p,[tabindex]');
  for(var i=0,k=0;i<cand.length&&k<2500;i++){
    var c=cand[i];if(seen.has(c))continue;
    var r=c.getBoundingClientRect();if(r.width<8||r.height<8||r.bottom<-vh*0.5||r.top>vh*2.2)continue;k++;
    var cs=getComputedStyle(c);
    if(cs.cursor!=='pointer'&&!c.hasAttribute('tabindex'))continue;
    var par=c.parentElement;if(par&&getComputedStyle(par).cursor==='pointer'){var pr=par.getBoundingClientRect();if(!(pr.width>vh*1.2&&pr.height>vh*0.6))continue;}
    if(c.closest('a[href],button'))continue;
    if(r.width>vh*1.2&&r.height>vh*0.6)continue;
    extra.push(c);seen.add(c);
  }
  els=els.concat(extra);
  els=els.filter(function(e){if(e.type==='hidden'||e.disabled)return false;if(!vis(e))return false;var r=e.getBoundingClientRect();return r.bottom>-vh*0.5&&r.top<vh*2.2;});
  els.sort(function(a,b){var ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();var ia=(ra.top>=0&&ra.top<vh)?0:1,ib=(rb.top>=0&&rb.top<vh)?0:1;return ia-ib||ra.top-rb.top;});
  els.slice(0,170).forEach(function(e){
    var id=++n;e.setAttribute('data-act',id);
    var tag=e.tagName.toLowerCase(),d;
    if(tag==='input'||tag==='textarea'){
      var ty=(e.type||'text').toLowerCase();
      if(ty==='checkbox'||ty==='radio')d='['+id+'] '+ty+(e.checked?' ✓':' ☐')+' "'+label(e)+'"';
      else if(/submit|button/.test(ty))d='['+id+'] button "'+(e.value||label(e))+'"';
      else d='['+id+'] input '+ty+' "'+label(e)+'"'+(e.value?' value="'+String(e.value).slice(0,40)+'"':'');
    }else if(tag==='select'){
      var o=[].slice.call(e.options).map(function(x){return x.text.trim();}).filter(Boolean).slice(0,25);
      d='['+id+'] select "'+label(e)+'" = "'+(e.options[e.selectedIndex]?e.options[e.selectedIndex].text.trim():'')+'" options: '+o.join(' | ');
    }else{
      var t=txt(e);if(!t&&tag==='a'){var im=e.querySelector('img');t=im?('img: '+(im.alt||'')).slice(0,80):'';}
      if(!t)t=e.getAttribute('href')?('→ '+e.getAttribute('href').slice(0,60)):'';
      d='['+id+'] '+(tag==='a'?'link':e.getAttribute('role')||(/^(div|span|li|p|img)$/.test(tag)?'кнопка':tag))+' "'+t+'"'+(FINAL.test(t)?' ⚠ФИНАЛЬНАЯ ОПЛАТА':'');
    }
    var r=e.getBoundingClientRect();if(r.top>vh)d+=' (ниже)';
    out.push(d);
  });
  var cap=/desliza|slide to verify|captcha|verificaci[oó]n de seguridad|проведите|nc_iconfont|baxia|punish/i.test(document.body.innerHTML.slice(0,200000))&&[].slice.call(document.querySelectorAll('#nc_1_n1z,.nc-container,[id*=baxia],[class*=captcha],iframe[src*=captcha],iframe[src*=punish]')).some(vis);
  var main=(document.querySelector('main,#dp,#ppd,[role=main]')||document.body).innerText.replace(/\n{2,}/g,'\n').replace(/[ \t]+/g,' ').slice(0,3500);
  return JSON.stringify({captcha:!!cap,url:location.href,title:document.title,scroll:Math.round(scrollY)+'/'+Math.round(document.documentElement.scrollHeight),elements:out.join('\n'),text:main});
};
function flash(e){try{var o=e.style.outline;e.style.outline='3px solid #7A5AFD';e.style.outlineOffset='2px';setTimeout(function(){e.style.outline=o;},900);}catch(x){}}
window.__actDo=function(c){
  try{
    if(c.type==='scroll'){window.scrollBy({top:(c.dir==='up'?-1:1)*innerHeight*0.8,behavior:'instant'});return JSON.stringify({ok:true});}
    var e=document.querySelector('[data-act="'+c.id+'"]');
    if(!e)return JSON.stringify({ok:false,err:'элемент ['+c.id+'] не найден — страница изменилась, сделай новый снимок'});
    var t=txt(e)||e.value||'';
    if(c.type==='click'&&FINAL.test(t)&&!c.confirmed)return JSON.stringify({ok:false,blocked:true,text:t});
    e.scrollIntoView({block:'center'});flash(e);
    if(c.type==='click'){
      ['pointerdown','mousedown','pointerup','mouseup'].forEach(function(ev){try{e.dispatchEvent(new MouseEvent(ev,{bubbles:true,cancelable:true,view:window}));}catch(x){}});
      e.click();return JSON.stringify({ok:true,clicked:t});
    }
    if(c.type==='type'){
      e.focus();var proto=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(e,c.text||'');
      e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));
      if(c.enter){
        ['keydown','keypress','keyup'].forEach(function(k){e.dispatchEvent(new KeyboardEvent(k,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});
        if(e.form){var b=e.form.querySelector('[type=submit],button:not([type])');if(b)b.click();else if(e.form.requestSubmit)e.form.requestSubmit();else e.form.submit();}
      }
      return JSON.stringify({ok:true});
    }
    if(c.type==='select'){
      var v=String(c.value||'').toLowerCase(),o=[].slice.call(e.options).find(function(x){return x.text.trim().toLowerCase()===v||x.value.toLowerCase()===v;})||[].slice.call(e.options).find(function(x){return x.text.toLowerCase().indexOf(v)>=0;});
      if(!o)return JSON.stringify({ok:false,err:'нет варианта «'+c.value+'»'});
      e.value=o.value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return JSON.stringify({ok:true});
    }
    return JSON.stringify({ok:false,err:'неизвестное действие'});
  }catch(err){return JSON.stringify({ok:false,err:String(err)});}
};
})();
