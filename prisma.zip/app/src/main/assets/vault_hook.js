(function(){try{
if(window.__pv){window.__pvReport&&window.__pvReport();return;}window.__pv=1;
function vis(e){return e&&!e.disabled&&e.offsetParent!==null;}
function userInput(scope){var q='input[type=email],input[autocomplete=username],input[autocomplete=email],input[name*=user i],input[name*=login i],input[name*=email i],input[id*=user i],input[id*=login i],input[id*=email i]';
 var e=[].slice.call((scope||document).querySelectorAll(q)).filter(vis)[0];return e||null;}
function grabUser(){var e=userInput();if(e&&e.value){try{sessionStorage.setItem('__pvu',e.value);}catch(x){}}}
function grab(){
 var pw=[].slice.call(document.querySelectorAll('input[type=password]')).filter(function(e){return e.value;})[0];if(!pw)return;
 var form=pw.form||document,u='';
 var ins=[].slice.call(form.querySelectorAll('input')).filter(function(e){return /^(text|email|tel)$/i.test(e.type||'text')&&e.value;});
 for(var i=0;i<ins.length;i++){if(ins[i].compareDocumentPosition(pw)&4)u=ins[i].value;}
 if(!u&&ins[0])u=ins[0].value;
 if(!u){try{u=sessionStorage.getItem('__pvu')||'';}catch(x){}}
 try{PrismaVault.offer(u,pw.value);}catch(x){}
}
document.addEventListener('submit',function(){grabUser();grab();},true);
document.addEventListener('click',function(e){var b=e.target&&e.target.closest&&e.target.closest('button,input[type=submit],input[type=button],[role=button],a');if(b){grabUser();grab();}},true);
document.addEventListener('keydown',function(e){if(e.key==='Enter'){grabUser();grab();}},true);
window.__pvReport=function(){
 var pw=[].slice.call(document.querySelectorAll('input[type=password]')).filter(vis).length>0;
 var us=!!userInput();
 try{PrismaVault.page(pw,us);}catch(x){}
 if(!pw&&window.__pfFill){try{var f=JSON.parse(window.__pfFill({},{fill:false}));PrismaVault.forms(f.profile||0,!!f.card);}catch(x){}}
};
window.__pvReport();
var n=0,iv=setInterval(function(){n++;window.__pvReport();if(n>5)clearInterval(iv);},1500);
}catch(e){}})()
