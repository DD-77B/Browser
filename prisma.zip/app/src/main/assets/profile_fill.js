window.__pfFill=function(P,opt){try{
opt=opt||{};var map=opt.map||{},card=!!opt.card,doFill=opt.fill!==false;
function vis(e){if(!e||e.disabled||e.readOnly||e.type==='hidden')return false;var r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden';}
function lab(e){var t=[e.name,e.id,e.placeholder,e.getAttribute('aria-label'),e.getAttribute('autocomplete'),e.title];
 if(e.id){var l=document.querySelector('label[for="'+CSS.escape(e.id)+'"]');if(l)t.push(l.innerText);}
 var p=e.closest('label');if(p)t.push(p.innerText);
 var prev=e.previousElementSibling;if(prev&&prev.innerText&&prev.innerText.length<60)t.push(prev.innerText);
 var par=e.parentElement;if(par&&!p){var pl=par.querySelector('label');if(pl&&pl.innerText.length<60)t.push(pl.innerText);}
 return t.filter(Boolean).join(' | ').replace(/\s+/g,' ').slice(0,160);}
var AC={'given-name':'given','additional-name':'','family-name':'family','name':'full','email':'email','tel':'tel','tel-national':'tel','street-address':'street','address-line1':'street','address-line2':'street2','address-level2':'city','address-level1':'region','postal-code':'zip','country':'country','country-name':'country','bday':'bday','cc-name':'ccName','cc-number':'ccNumber','cc-exp':'ccExp','cc-exp-month':'ccMonth','cc-exp-year':'ccYear','cc-csc':'SKIP','one-time-code':'SKIP','username':'email','new-password':'SKIP','current-password':'SKIP'};
var RX=[['SKIP',/cvv|cvc|csc|cód.*seg|security code|код безоп|captcha|coupon|cup[oó]n|promo|search|buscar|поиск|password|contraseñ|пароль/i],
 ['ccNumber',/card ?num|cardnumber|cc-?num|n[uú]mero de (la )?tarjeta|номер карт|numéro de carte/i],
 ['ccName',/(card ?holder|name on card|titular|nombre en la tarjeta|владел.*карт|держател)/i],
 ['ccExp',/exp(iry|iration)?( date)?$|mm ?\/ ?yy|caducidad|vencimiento|срок действия карт|date d.expiration/i],
 ['email',/e-?mail|correo|почт|courriel/i],
 ['tel',/phone|tel[eé]fono|m[oó]vil|mobile|телефон|t[eé]l[eé]phone|cell/i],
 ['passport',/passport|pasaporte|паспорт|passeport/i],
 ['dni',/\b(dni|nie|nif|id ?number|documento|national id|n[uú]mero de identidad|удостовер)/i],
 ['bday',/birth|nacimiento|рожд|naissance|dob/i],
 ['family',/last ?name|surname|family|apellido|фамил|nom de famille|\bnom\b/i],
 ['given',/first ?name|given|forename|\bnombre\b|\bимя\b|pr[eé]nom/i],
 ['full',/full ?name|your name|nombre completo|\bname\b|ф\.?и\.?о|имя и фамилия/i],
 ['zip',/zip|postal|post ?code|c[oó]digo postal|\bcp\b|индекс|code postal|plz/i],
 ['city',/city|town|ciudad|localidad|municipio|город|ville|населен/i],
 ['region',/state|province|provincia|region|регион|область|r[eé]gion/i],
 ['country',/country|pa[ií]s|страна|pays/i],
 ['street2',/address ?(line)? ?2|apartment|apt|suite|piso|puerta|квартир|compl[eé]ment/i],
 ['street',/address|street|direcci[oó]n|calle|domicilio|адрес|улиц|adresse|rue/i]];
var els=[].slice.call(document.querySelectorAll('input,select,textarea')).filter(function(e){return vis(e)&&!/^(submit|button|reset|checkbox|radio|file|image|range|color|password)$/i.test(e.type||'');});
function setv(el,v){if(el.tagName==='SELECT'){var o=[].slice.call(el.options),lv=String(v).toLowerCase();
   var m=o.find(function(x){return x.value.toLowerCase()===lv||x.text.trim().toLowerCase()===lv;})||o.find(function(x){return lv.length>2&&(x.text.toLowerCase().indexOf(lv)>=0||lv.indexOf(x.text.trim().toLowerCase())>=0)&&x.text.trim().length>1;});
   if(!m)return false;el.value=m.value;}
 else{var d=Object.getOwnPropertyDescriptor(el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value');d.set.call(el,v);}
 el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));el.dispatchEvent(new Event('blur',{bubbles:true}));return true;}
function val(k,el){var v=P[k];
 if(k==='full'&&!v&&(P.given||P.family))v=((P.given||'')+' '+(P.family||'')).trim();
 if(k==='ccExp'&&!v&&P.ccMonth)v=P.ccMonth+'/'+String(P.ccYear||'').slice(-2);
 if(k==='ccMonth'&&!v&&P.ccExp)v=P.ccExp.split('/')[0];
 if(k==='ccYear'&&!v&&P.ccExp){var y=P.ccExp.split('/')[1]||'';v=(el&&el.tagName==='SELECT'&&y.length===2)?'20'+y:y;}
 if(k==='bday'&&v&&el&&el.type!=='date'&&/^\d{4}-\d{2}-\d{2}$/.test(v)){var a=v.split('-');v=a[2]+'/'+a[1]+'/'+a[0];}
 if(k==='country'&&v&&el&&el.tagName==='SELECT'){var alt={'испания':'Spain','spain':'España','españa':'Spain'};if(!setv(el,v)&&alt[v.toLowerCase()])v=alt[v.toLowerCase()];}
 return v;}
var filled=[],unmatched=[],cardSeen=false,profileSeen=0;
els.forEach(function(e,i){e.setAttribute('data-pf',i);
 var ac=(e.getAttribute('autocomplete')||'').toLowerCase().split(/\s+/).pop(),k=map[i]||AC[ac];
 if(!k){var L=lab(e);for(var r=0;r<RX.length;r++){if(RX[r][1].test(L)){k=RX[r][0];break;}}
   if(!k&&e.type==='email')k='email';if(!k&&e.type==='tel')k='tel';}
 if(k==='SKIP')return;
 if(!k){if(e.tagName!=='SELECT'||e.options.length<60)unmatched.push({i:i,label:lab(e)});return;}
 if(/^cc/.test(k)){cardSeen=true;if(!card)return;}else profileSeen++;
 if(!doFill)return;
 if(e.value&&e.value.trim()&&!map[i])return;
 var v=val(k,e);if(v==null||v==='')return;
 if(setv(e,v))filled.push(k);});
return JSON.stringify({filled:filled,unmatched:unmatched.slice(0,25),card:cardSeen,profile:profileSeen});
}catch(err){return JSON.stringify({error:String(err)});}};
