(function(){if(window.__pc)return;window.__pc=1;
function put(t){try{PrismaClip.copy(String(t));return Promise.resolve();}catch(e){return Promise.reject(e);}}
try{
  if(!navigator.clipboard)Object.defineProperty(navigator,'clipboard',{value:{},configurable:true});
  var cb=navigator.clipboard,ow=cb.write&&cb.write.bind(cb);
  cb.writeText=put;
  cb.write=function(items){return (async function(){
    try{for(var i=0;i<items.length;i++){var it=items[i];if(it.types&&it.types.indexOf('text/plain')>=0){var b=await it.getType('text/plain');return put(await b.text());}}}catch(e){}
    if(ow)return ow(items);throw new Error('unsupported');})();};
}catch(e){}
try{
  var oe=document.execCommand.bind(document);
  document.execCommand=function(c){
    if(String(c).toLowerCase()==='copy'){
      var t='',ae=document.activeElement;
      try{if(ae&&(ae.tagName==='TEXTAREA'||ae.tagName==='INPUT')&&typeof ae.selectionStart==='number')t=ae.value.substring(ae.selectionStart,ae.selectionEnd);}catch(e){}
      if(!t)t=String(window.getSelection?getSelection():'');
      var r=false;try{r=oe.apply(document,arguments);}catch(e){}
      if(t){put(t);return true;}
      return r;
    }
    return oe.apply(document,arguments);
  };
}catch(e){}
})();
