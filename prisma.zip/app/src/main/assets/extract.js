(function(){try{
var sel=String(window.getSelection?window.getSelection():'');
var root=document.querySelector('article')||document.querySelector('main')||document.querySelector('[role=main]');
if(!root){var best=null,bs=0;document.querySelectorAll('div,section').forEach(function(d){var s=0;for(var i=0;i<d.children.length;i++){var c=d.children[i];if(c.tagName==='P')s+=(c.innerText||'').length;}if(s>bs){bs=s;best=d;}});root=(best&&bs>500)?best:document.body;}
var paras=[];root.querySelectorAll('h1,h2,h3,p,li,blockquote,pre').forEach(function(e){if(e.closest('nav,footer,aside,form,header'))return;var t=(e.innerText||'').trim();if(t.length>1)paras.push({t:e.tagName.toLowerCase(),x:t.slice(0,3000)});});
var text=paras.map(function(p){return p.x;}).join('\n');
var body=(document.body&&document.body.innerText)||'';
if(text.length<300)text=body;
var phones=[];document.querySelectorAll('a[href^="tel:"]').forEach(function(a){try{phones.push(decodeURIComponent(a.getAttribute('href').slice(4)).trim());}catch(e){}});
(body.match(/\+?\d[\d\s().-]{7,}\d/g)||[]).forEach(function(s){var d=s.replace(/\D/g,'');if(d.length>=9&&d.length<=15&&!/^\d{4}[-.]\d{2}[-.]\d{2}/.test(s.trim()))phones.push(s.trim());});
var emails=body.match(/[\w.+-]+@[\w-]+\.[a-z]{2,}/gi)||[];
document.querySelectorAll('a[href^="mailto:"]').forEach(function(a){emails.push(a.getAttribute('href').slice(7).split('?')[0]);});
var md=function(n){var m=document.querySelector('meta[name="'+n+'"],meta[property="'+n+'"]');return m?(m.content||''):'';};
var uniq=function(a){var o=[],s={};a.forEach(function(x){if(!s[x]){s[x]=1;o.push(x);}});return o;};
return {url:location.href,title:document.title,lang:document.documentElement.lang||'',text:text.slice(0,40000),paras:paras.slice(0,500),
phones:uniq(phones).slice(0,10),emails:uniq(emails).slice(0,10),desc:md('description')||md('og:description'),site:md('og:site_name'),
image:md('og:image'),selection:sel.slice(0,5000)};
}catch(e){return {error:String(e),url:location.href,title:document.title,text:((document.body&&document.body.innerText)||'').slice(0,40000),paras:[],phones:[],emails:[]};}})()
