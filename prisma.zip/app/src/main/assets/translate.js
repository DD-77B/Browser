(function(){
if(window.__tr)return;
var SKIP=/^(SCRIPT|STYLE|NOSCRIPT|CODE|PRE|TEXTAREA|INPUT|SELECT|OPTION|SVG|MATH|KBD|SAMP|VAR|IFRAME|CANVAS|TEMPLATE)$/;
var S={on:false,to:'ru',orig:new Map(),attrOrig:[],pend:{},queue:[],seq:0,inflight:0,cache:{},obs:null,timer:null};
window.__tr=S;
function letters(s){return /[A-Za-zÀ-ɏ\u0400-\u04FF\u0370-\u03FF]/.test(s);}
function skipEl(el){for(var e=el;e&&e!==document.body;e=e.parentElement){if(SKIP.test(e.tagName)||e.isContentEditable||e.getAttribute&&(e.getAttribute('translate')==='no'||e.classList.contains('notranslate')))return true;}return false;}
var INL=/^(A|B|STRONG|I|EM|SPAN|U|SMALL|MARK|ABBR|SUP|SUB|FONT|S|Q|CITE|TIME|LABEL)$/;
var blkOk=new WeakMap();
function blockOf(n){
  var p=n.parentElement;if(!p)return null;
  var b=INL.test(p.tagName)?p.parentElement:p;
  if(!b||b===document.body||SKIP.test(b.tagName))return null;
  if(blkOk.has(b))return blkOk.get(b);
  var ok=true,inl=0,txt=0;
  for(var c=b.firstChild;c;c=c.nextSibling){
    if(c.nodeType===3){if(c.nodeValue.trim())txt++;continue;}
    if(c.nodeType===8)continue;
    if(c.nodeType!==1||!INL.test(c.tagName)||c.children.length||++inl>8){ok=false;break;}
  }
  var r=ok&&inl>0&&txt>0?b:null;blkOk.set(b,r);return r;
}
function serialize(b){
  var parts=[],src='';
  for(var c=b.firstChild;c;c=c.nextSibling){
    if(c.nodeType===3)src+=c.nodeValue.replace(/</g,'‹');
    else if(c.nodeType===1){var k=parts.length;parts.push(c);src+='<x'+k+'>'+(c.textContent||'').replace(/</g,'‹')+'</x'+k+'>';}
  }
  return{src:src.replace(/\s+/g,' ').trim(),parts:parts};
}
var inBlk=new WeakSet();
function collect(root){
  var out=[],w=document.createTreeWalker(root||document.body,NodeFilter.SHOW_TEXT,null),n;
  while((n=w.nextNode())){
    if(S.orig.has(n)||inBlk.has(n))continue;
    var b=n.parentElement&&!skipEl(n.parentElement)?blockOf(n):null;
    if(b&&!b.__trOrig&&!b.__trQ){
      var z=serialize(b);
      if(z.src.length>1&&letters(z.src)){b.__trQ=1;out.push({blk:b,src:z.src,parts:z.parts});
        for(var c=b.firstChild;c;c=c.nextSibling){if(c.nodeType===3)inBlk.add(c);else if(c.firstChild)inBlk.add(c.firstChild);}
        continue;}
    }
    if(b&&(b.__trOrig||b.__trQ))continue;
    var v=n.nodeValue,t=v.trim();
    if(t.length<2||!letters(t)||/^[\d\s.,:;%€$£+\-–—/()]+$/.test(t))continue;
    if(!n.parentElement||skipEl(n.parentElement))continue;
    out.push({n:n,src:t,lead:v.match(/^\s*/)[0],trail:v.match(/\s*$/)[0]});
  }
  var els=(root&&root.querySelectorAll?root:document).querySelectorAll('[placeholder],[title],input[type=submit][value],input[type=button][value],img[alt]');
  for(var i=0;i<els.length;i++){var el=els[i];['placeholder','title','value','alt'].forEach(function(a){
    if(a==='value'&&!(el.tagName==='INPUT'&&/submit|button/i.test(el.type)))return;
    var v=el.getAttribute(a);if(!v||v.trim().length<2||!letters(v)||el['__tr_'+a])return;
    out.push({el:el,attr:a,src:v.trim()});});}
  // what is on screen first
  var vh=innerHeight;
  out.forEach(function(it){var p=it.blk||(it.n?it.n.parentElement:it.el);var r=p?p.getBoundingClientRect():{top:9e9};it.k=(r.top>=-50&&r.top<vh+200)?r.top:1e6+Math.abs(r.top);});
  out.sort(function(a,b){return a.k-b.k;});
  return out;
}
function apply(it,t){
  if(typeof t!=='string'||!t)return;
  if(it.blk){
    var b=it.blk;b.__trQ=0;
    if(!b.__trOrig){b.__trOrig={nodes:[].slice.call(b.childNodes),texts:it.parts.map(function(e){return e.textContent;})};S.orig.set(b,null);}
    var frag=document.createDocumentFragment(),used={},re=/<x(\d+)>([\s\S]*?)<\/x\1>/g,last=0,m;
    while((m=re.exec(t))){
      if(m.index>last)frag.appendChild(document.createTextNode(t.slice(last,m.index).replace(/<\/?x\d+>/g,'')));
      var el=it.parts[+m[1]];if(el&&!used[m[1]]){used[m[1]]=1;el.textContent=m[2];frag.appendChild(el);}
      last=re.lastIndex;
    }
    if(last<t.length)frag.appendChild(document.createTextNode(t.slice(last).replace(/<\/?x\d+>/g,'')));
    it.parts.forEach(function(el,k){if(!used[k])frag.appendChild(el);});
    while(b.firstChild)b.removeChild(b.firstChild);
    b.appendChild(frag);
    return;
  }
  if(it.n){if(!S.orig.has(it.n))S.orig.set(it.n,it.n.nodeValue);it.n.nodeValue=it.lead+t+it.trail;}
  else{if(!it.el['__tr_'+it.attr]){S.attrOrig.push([it.el,it.attr,it.el.getAttribute(it.attr)]);it.el['__tr_'+it.attr]=1;}it.el.setAttribute(it.attr,t);}
}
function pump(){
  if(!S.on)return;
  while(S.inflight<3&&S.queue.length){
    var batch=[],chars=0;
    while(S.queue.length&&batch.length<45&&chars<3200){
      var it=S.queue.shift();
      if(S.cache[it.src]!=null){apply(it,S.cache[it.src]);continue;}
      batch.push(it);chars+=it.src.length;
    }
    if(!batch.length)continue;
    var id='t'+(++S.seq);S.pend[id]=batch;S.inflight++;
    var uniq=[];batch.forEach(function(b){if(uniq.indexOf(b.src)<0)uniq.push(b.src);});
    batch.uniq=uniq;
    try{PrismaTr.request(id,JSON.stringify({to:S.to,from:window.__trLang(),items:uniq}));}catch(e){S.inflight--;}
  }
  if(S.queue.length===0&&S.inflight===0){try{PrismaTr.progress(0);}catch(e){}}
  else{try{PrismaTr.progress(S.queue.length+S.inflight*40);}catch(e){}}
}
window.__trApply=function(id,arr){
  var b=S.pend[id];delete S.pend[id];S.inflight=Math.max(0,S.inflight-1);
  if(b&&Array.isArray(arr)){b.uniq.forEach(function(src,i){if(typeof arr[i]==='string'&&arr[i])S.cache[src]=arr[i];});
    if(S.on)b.forEach(function(it){apply(it,S.cache[it.src]);});}
  pump();
};
function enqueue(root){S.queue=S.queue.concat(collect(root));pump();}
window.__trStart=function(to){
  S.to=to||'ru';
  if(S.on)return;S.on=true;
  enqueue(document.body);
  S.obs=new MutationObserver(function(ms){
    if(!S.on)return;clearTimeout(S.timer);
    S.timer=setTimeout(function(){enqueue(document.body);},500);
  });
  S.obs.observe(document.body,{childList:true,subtree:true,characterData:false});
  var lastY=scrollY;
  window.addEventListener('scroll',function(){if(S.on&&Math.abs(scrollY-lastY)>innerHeight){lastY=scrollY;S.queue.forEach(function(it){var p=it.n?it.n.parentElement:it.el;var r=p?p.getBoundingClientRect():{top:9e9};it.k=(r.top>=-50&&r.top<innerHeight+200)?r.top:1e6+Math.abs(r.top);});S.queue.sort(function(a,b){return a.k-b.k;});}},{passive:true});
};
window.__trStop=function(){
  S.on=false;if(S.obs)S.obs.disconnect();S.queue=[];
  S.orig.forEach(function(v,n){
    if(n.__trOrig){var o=n.__trOrig;o.nodes.forEach(function(x){if(x.nodeType===1){}});
      while(n.firstChild)n.removeChild(n.firstChild);
      var k=0;o.nodes.forEach(function(x){if(x.nodeType===1&&o.texts[k]!=null&&INL.test(x.tagName)){x.textContent=o.texts[k++];}n.appendChild(x);});
      n.__trOrig=null;}
    else n.nodeValue=v;});
  S.orig=new Map();inBlk=new WeakSet();blkOk=new WeakMap();
  S.attrOrig.forEach(function(a){a[0].setAttribute(a[1],a[2]);delete a[0]['__tr_'+a[1]];});S.attrOrig=[];
  try{PrismaTr.progress(0);}catch(e){}
};
window.__trLang=function(){
  if(window.__trL)return window.__trL;
  var txt=((document.body&&document.body.innerText)||'').slice(0,6000).toLowerCase();
  var cyr=(txt.match(/[а-яё]/g)||[]).length,lat=(txt.match(/[a-zà-ÿ]/g)||[]).length;
  var lang='';
  if(cyr>lat*0.6&&cyr>40)lang=/[іїєґ]/.test(txt)&&(txt.match(/[іїєґ]/g)||[]).length>8?'uk':'ru';
  else{
    var W={es:[' el ',' la ',' los ',' las ',' que ',' del ',' para ',' con ',' una ',' por ',' es ',' y '],
      en:[' the ',' and ',' of ',' to ',' is ',' for ',' with ',' you ',' this ',' are '],
      fr:[' le ',' les ',' des ',' et ',' est ',' pour ',' une ',' dans ',' vous ',' du '],
      de:[' der ',' die ',' und ',' das ',' ist ',' nicht ',' mit ',' sie ',' ein ',' für '],
      it:[' il ',' che ',' di ',' per ',' una ',' sono ',' della ',' gli ',' è ',' non '],
      pt:[' não ',' que ',' com ',' uma ',' para ',' os ',' do ',' da ',' é ',' em ']};
    var best='',bs=0,t=' '+txt.replace(/[^a-zà-ÿ]+/g,' ')+' ';
    for(var k in W){var sc=0;W[k].forEach(function(w){var i=-1;while((i=t.indexOf(w,i+1))>=0)sc++;});if(sc>bs){bs=sc;best=k;}}
    lang=bs>=8?best:((document.documentElement.lang||'').slice(0,2).toLowerCase());
  }
  window.__trL=lang;return lang;
};
})();
